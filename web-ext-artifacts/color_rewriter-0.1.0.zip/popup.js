import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from './assets/client-Cgcb47Pj.js';

const DEFAULTS = { style: "Original", colorOverrides: {} };
function Popup() {
  const [settings, setSettings] = reactExports.useState(DEFAULTS);
  const [status, setStatus] = reactExports.useState({ loading: false });
  const [palette, setPalette] = reactExports.useState([]);
  const [activeTab, setActiveTab] = reactExports.useState(null);
  reactExports.useEffect(() => {
    browser.storage.local.get(["settings", "currentPalette"]).then((result) => {
      if (result.settings) {
        setSettings(result.settings);
      }
      if (result.currentPalette) {
        const paletteEntries = Object.entries(result.currentPalette).map(
          ([original, replacement]) => ({ original, replacement: String(replacement) })
        );
        setPalette(paletteEntries);
      }
    });
    browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (tabs[0]?.id) setActiveTab(tabs[0].id);
    });
  }, []);
  const saveAndApply = async () => {
    try {
      setStatus({ loading: true });
      await browser.storage.local.set({ settings });
      let finalPalette = {};
      if (palette.length > 0 && settings.colorOverrides) {
        finalPalette = Object.fromEntries(palette.map(({ original, replacement }) => {
          const overrideColor = settings.colorOverrides?.[original];
          return [original, overrideColor || replacement];
        }));
      }
      const response = await browser.runtime.sendMessage({
        type: "REFRESH_PALETTE",
        settings,
        colorOverrides: settings.colorOverrides
      });
      if (!response) {
        throw new Error("No response from background script");
      }
      if (!response.success) {
        throw new Error(response.error || "Failed to apply palette");
      }
      setStatus({ loading: false });
    } catch (error) {
      console.error("Error applying palette:", error);
      setStatus({ loading: false, error: error.message || "Failed to apply palette" });
    }
  };
  const onSelect = (e) => {
    const style = e.target.value;
    setSettings((s) => ({ ...s, style }));
  };
  const handleColorOverride = (originalColor, newColor) => {
    setSettings((s) => ({
      ...s,
      colorOverrides: {
        ...s.colorOverrides || {},
        [originalColor]: newColor
      }
    }));
  };
  const openOptions = () => {
    browser.runtime.openOptionsPage();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 text-sm space-y-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block mb-1", children: "Palette" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "select",
        {
          className: "w-full border rounded p-1",
          value: settings.style,
          onChange: onSelect,
          disabled: status.loading,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Original", children: "Original" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Light", children: "Light" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Dark", children: "Dark" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Custom", children: "Custom..." })
          ]
        }
      )
    ] }),
    settings.style === "Custom" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "textarea",
      {
        className: "w-full border rounded p-1",
        rows: 3,
        placeholder: "Describe your palette (e.g. 'pastel sunset')",
        value: settings.customDescription || "",
        onChange: (e) => setSettings((s) => ({ ...s, customDescription: e.target.value })),
        disabled: status.loading
      }
    ),
    palette.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium mb-2", children: "Color Palette" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-2 max-h-64 overflow-y-auto", children: palette.map(({ original, replacement }, idx) => {
        const overrideColor = settings.colorOverrides?.[original];
        const finalColor = overrideColor || replacement;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "color-preview border", style: { backgroundColor: original } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs truncate", children: original })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-1", children: "→" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "color-preview border", style: { backgroundColor: finalColor }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "color",
                className: "opacity-0 absolute",
                value: finalColor,
                onChange: (e) => handleColorOverride(original, e.target.value)
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs truncate", children: finalColor })
          ] })
        ] }, idx);
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-center mt-2", children: "Click on right color to override" })
    ] }),
    status.error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-red-500 text-xs p-2 bg-red-50 rounded border border-red-200", children: [
      "Error: ",
      status.error
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        className: `w-full rounded py-1 ${status.loading ? "bg-gray-400 text-white cursor-not-allowed" : "bg-indigo-600 text-white hover:bg-indigo-700"}`,
        onClick: saveAndApply,
        disabled: status.loading,
        children: status.loading ? "Applying..." : "Apply"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-center mt-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: openOptions,
        className: "text-blue-600 hover:text-blue-800 hover:underline",
        children: "Options"
      }
    ) })
  ] });
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}));
