import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from './assets/client-Cgcb47Pj.js';

const STORAGE_KEYS = {
  SAVED_PALETTES_BY_TLD: "savedPalettesByTld",
  TLD_ACTIVE_SETTINGS: "tldActiveSettings",
  PROVIDER_SETTINGS: ["provider", "ollamaUrl", "openaiKey", "claudeKey"],
  CURRENT_PALETTE: "currentPalette"
};
const DEFAULTS = { style: "Original", colorOverrides: {} };
function Popup() {
  const [settings, setSettings] = reactExports.useState(DEFAULTS);
  const [status, setStatus] = reactExports.useState({ loading: false });
  const [palette, setPalette] = reactExports.useState([]);
  const [activeTab, setActiveTab] = reactExports.useState(null);
  reactExports.useEffect(() => {
    browser.storage.local.get(["settings", STORAGE_KEYS.CURRENT_PALETTE]).then((result) => {
      if (result.settings) {
        setSettings((s) => ({ ...s, ...result.settings }));
      }
      if (result[STORAGE_KEYS.CURRENT_PALETTE]) {
        const currentPaletteMap = result[STORAGE_KEYS.CURRENT_PALETTE];
        setPalette(Object.entries(currentPaletteMap).map(([original, replacement]) => ({ original, replacement })));
      }
    }).catch((e) => console.error("Error loading initial settings/palette from storage:", e));
    browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (tabs[0]) {
        setActiveTab(tabs[0]);
        if (tabs[0].url) {
          browser.runtime.sendMessage({ type: "GET_ACTIVE_SETTINGS_FOR_TLD" }).then((activeTldSettings) => {
            if (activeTldSettings) {
              setSettings((prev) => ({
                ...prev,
                // Keep existing general settings or DEFAULTS
                style: activeTldSettings.style || prev.style,
                customDescription: activeTldSettings.customDescription === void 0 ? prev.customDescription : activeTldSettings.customDescription,
                colorOverrides: activeTldSettings.colorOverrides || prev.colorOverrides || {}
              }));
              if (activeTldSettings.palette) {
                const paletteArray = Object.entries(activeTldSettings.palette).map(([original, replacement]) => ({ original, replacement }));
                setPalette(paletteArray);
              }
            }
          }).catch((e) => console.error("Error getting active TLD settings in popup:", e));
        }
      } else {
        console.error("No active tab found.");
        setStatus({ loading: false, error: "No active tab found." });
      }
    }).catch((e) => {
      console.error("Error querying active tab:", e);
      setStatus({ loading: false, error: "Could not get active tab information." });
    });
  }, []);
  const saveAndApply = async () => {
    setStatus({ loading: true, error: void 0 });
    try {
      let tabToRefresh = activeTab;
      if (!tabToRefresh || !tabToRefresh.id || !tabToRefresh.url) {
        console.warn("Active tab from state is invalid, re-querying...");
        const currentTabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (currentTabs[0] && currentTabs[0].id && currentTabs[0].url) {
          tabToRefresh = currentTabs[0];
          setActiveTab(tabToRefresh);
        } else {
          throw new Error("Active tab information is missing or invalid. Cannot apply palette.");
        }
      }
      await browser.storage.local.set({ settings: { style: settings.style, customDescription: settings.customDescription, colorOverrides: settings.colorOverrides } });
      const response = await browser.runtime.sendMessage({
        type: "REFRESH_PALETTE",
        settings,
        // Send the current settings from the popup
        targetTab: tabToRefresh
        // Pass the full tab object
      });
      if (response && response.success) {
        console.log("Palette refresh initiated successfully by popup.");
        const updatedStorage = await browser.storage.local.get(STORAGE_KEYS.CURRENT_PALETTE);
        if (updatedStorage[STORAGE_KEYS.CURRENT_PALETTE]) {
          const newPaletteMap = updatedStorage[STORAGE_KEYS.CURRENT_PALETTE];
          setPalette(Object.entries(newPaletteMap).map(([original, replacement]) => ({ original, replacement })));
        }
      } else {
        throw new Error(response?.error || "Failed to refresh palette via background script");
      }
    } catch (err) {
      console.error("Error in saveAndApply:", err);
      setStatus({ loading: false, error: err.message });
    } finally {
      setStatus({ loading: false });
    }
  };
  const onSelect = (e) => {
    const newStyle = e.target.value;
    setSettings((s) => ({ ...s, style: newStyle, customDescription: newStyle === "Custom" ? s.customDescription : void 0 }));
  };
  const handleColorOverride = (originalColor, newColor) => {
    setSettings((s) => {
      const newOverrides = { ...s.colorOverrides };
      if (newColor && newColor !== originalColor) {
        newOverrides[originalColor] = newColor;
      } else {
        delete newOverrides[originalColor];
      }
      return { ...s, colorOverrides: newOverrides };
    });
  };
  const openOptions = () => {
    browser.runtime.openOptionsPage();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 space-y-3 text-sm", style: { width: "250px" }, children: [
    " ",
    /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: settings.style, onChange: onSelect, className: "w-full border rounded p-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Original", children: "Original Site Colors" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Light", children: "Light Mode" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Dark", children: "Dark Mode" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Custom", children: "Custom AI Palette" })
    ] }),
    settings.style === "Custom" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type: "text",
        placeholder: "Describe custom style (e.g., 'ocean blue theme')",
        value: settings.customDescription || "",
        onChange: (e) => setSettings((s) => ({ ...s, customDescription: e.target.value })),
        className: "w-full border rounded p-1"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: saveAndApply, disabled: status.loading, className: "w-full bg-indigo-600 text-white py-1 rounded hover:bg-indigo-700 disabled:bg-gray-400", children: status.loading ? "Applying..." : "Save & Apply" }),
    status.error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-red-500 text-xs p-2 bg-red-50 border border-red-200 rounded", children: status.error }),
    palette.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-h-64 overflow-y-auto space-y-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium", children: "Current Palette:" }),
      palette.map(({ original, replacement }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2 items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate", style: { color: original, backgroundColor: "#f0f0f0", padding: "2px" }, title: original, children: original }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "color",
            value: settings.colorOverrides?.[original] || replacement,
            onChange: (e) => handleColorOverride(original, e.target.value),
            className: "p-0 border-0 w-full h-6",
            title: "Override color"
          }
        )
      ] }, original))
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: openOptions, className: "w-full text-center text-xs py-1 mt-2 text-indigo-600 hover:underline", children: "Options" })
  ] });
}
const rootDiv = document.getElementById("root");
if (rootDiv) {
  createRoot(rootDiv).render(/* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}));
} else {
  console.error("Root element not found for popup");
}
