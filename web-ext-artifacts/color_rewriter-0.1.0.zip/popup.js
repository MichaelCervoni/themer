import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from './assets/client-Cgcb47Pj.js';

const DEFAULTS = { style: "Original" };
function Popup() {
  const [settings, setSettings] = reactExports.useState(DEFAULTS);
  reactExports.useEffect(() => {
    browser.storage.local.get("settings").then((result) => {
      if (result.settings) {
        setSettings(result.settings);
      }
    });
  }, []);
  const saveAndApply = async () => {
    await browser.storage.local.set({ settings });
    await browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (tabs[0]?.id) {
        browser.tabs.sendMessage(tabs[0].id, { type: "REFRESH_PALETTE" });
      }
    });
    window.close();
  };
  const onSelect = (e) => {
    const style = e.target.value;
    setSettings((s) => ({ ...s, style }));
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 text-sm space-y-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block mb-1", children: "Palette" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "select",
        {
          className: "w-full border rounded p-1",
          value: settings.style,
          onChange: onSelect,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Original", children: "Original" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Light", children: "Light" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Dark", children: "Dark" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Custom", children: "Custom..." })
          ]
        }
      )
    ] }),
    settings.style === "Custom" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "textarea",
      {
        className: "w-full border rounded p-1",
        rows: 3,
        placeholder: "Describe your palette (e.g. 'pastel sunset')",
        value: settings.customDescription,
        onChange: (e) => setSettings((s) => ({ ...s, customDescription: e.target.value }))
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        className: "w-full rounded bg-indigo-600 text-white py-1 hover:bg-indigo-700",
        onClick: saveAndApply,
        children: "Apply"
      }
    )
  ] });
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}));
