import { R as React, j as jsxRuntimeExports, c as createRoot, r as reactExports } from './assets/styles-CVN6-g9y.js';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("Popup Error:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { padding: "16px", textAlign: "center" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Something went wrong" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { color: "red" }, children: this.state.error?.message || "Unknown error" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => browser.runtime.openOptionsPage(), children: "Open Options" })
      ] });
    }
    return this.props.children;
  }
}
function Popup() {
  const [state, setState] = reactExports.useState({
    styles: ["Original", "Dark", "Light", "Solarized", "Nord", "Custom"],
    currentStyle: "Dark",
    customDescription: "",
    loading: false,
    message: "",
    error: "",
    activeTab: null,
    colorOverrides: {}
  });
  reactExports.useEffect(() => {
    browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (tabs[0]) {
        setState((s) => ({ ...s, activeTab: tabs[0] }));
        browser.runtime.sendMessage({
          type: "GET_ACTIVE_SETTINGS_FOR_TLD",
          tabId: tabs[0].id,
          url: tabs[0].url
        }).then((settings) => {
          if (settings) {
            setState((s) => ({
              ...s,
              currentStyle: settings.style || s.currentStyle,
              customDescription: settings.customDescription || s.customDescription,
              colorOverrides: settings.colorOverrides || s.colorOverrides
            }));
          }
        }).catch((err) => {
          console.error("Error getting active settings:", err);
        });
      }
    });
  }, []);
  const applyTheme = async () => {
    setState((s) => ({ ...s, loading: true, error: "", message: "" }));
    try {
      if (!state.activeTab?.id) {
        throw new Error("No active tab");
      }
      const result = await browser.runtime.sendMessage({
        type: "REFRESH_PALETTE",
        targetTab: state.activeTab,
        settings: {
          style: state.currentStyle,
          customDescription: state.customDescription,
          colorOverrides: state.colorOverrides
        }
      });
      if (result.success) {
        setState((s) => ({
          ...s,
          loading: false,
          message: "Theme applied successfully"
        }));
        setTimeout(() => setState((s) => ({ ...s, message: "" })), 2e3);
      } else {
        throw new Error(result.error || "Unknown error");
      }
    } catch (error) {
      console.error("Error applying theme:", error);
      setState((s) => ({
        ...s,
        loading: false,
        error: error instanceof Error ? error.message : String(error)
      }));
    }
  };
  const openOptions = () => {
    browser.runtime.openOptionsPage();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-center mb-4", children: "Color Rewriter" }),
    state.error && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-red-100 border border-red-400 text-red-700 px-3 py-2 rounded mb-4", children: state.error }),
    state.message && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-green-100 border border-green-400 text-green-700 px-3 py-2 rounded mb-4", children: state.message }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium mb-1", children: "Theme Style" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "select",
        {
          className: "w-full p-2 border rounded",
          value: state.currentStyle,
          onChange: (e) => setState((s) => ({ ...s, currentStyle: e.target.value })),
          children: state.styles.map((style) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: style, children: style }, style))
        }
      )
    ] }),
    state.currentStyle === "Custom" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium mb-1", children: "Custom Description" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          className: "w-full p-2 border rounded",
          placeholder: "e.g., blue cyberpunk theme",
          value: state.customDescription,
          onChange: (e) => setState((s) => ({ ...s, customDescription: e.target.value }))
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded",
          onClick: applyTheme,
          disabled: state.loading,
          children: state.loading ? "Applying..." : "Apply Theme"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded",
          onClick: openOptions,
          children: "⚙️"
        }
      )
    ] })
  ] });
}
const rootDiv = document.getElementById("root");
if (rootDiv) {
  createRoot(rootDiv).render(
    /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}) })
  );
} else {
  console.error("Root element not found for popup");
}
