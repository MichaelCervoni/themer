import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from './assets/client-Cgcb47Pj.js';

const DEFAULTS = { style: "Original" };
function Popup() {
  const [settings, setSettings] = reactExports.useState(DEFAULTS);
  const [status, setStatus] = reactExports.useState({ loading: false });
  reactExports.useEffect(() => {
    browser.storage.local.get("settings").then((result) => {
      if (result.settings) {
        setSettings(result.settings);
      }
    });
  }, []);
  const saveAndApply = async () => {
    try {
      setStatus({ loading: true });
      await browser.storage.local.set({ settings });
      console.log("Saved settings:", settings);
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      if (!tabs[0]?.id) {
        throw new Error("No active tab found");
      }
      const response = await browser.runtime.sendMessage({
        type: "REFRESH_PALETTE",
        settings
      });
      console.log("Response from background:", response);
      if (!response.success) {
        throw new Error(response.error || "Failed to apply palette");
      }
      setStatus({ loading: false });
      window.close();
    } catch (error) {
      console.error("Error applying palette:", error);
      setStatus({ loading: false, error: error.message || "Failed to apply palette" });
    }
  };
  const onSelect = (e) => {
    const style = e.target.value;
    setSettings((s) => ({ ...s, style }));
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 text-sm space-y-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block mb-1", children: "Palette" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "select",
        {
          className: "w-full border rounded p-1",
          value: settings.style,
          onChange: onSelect,
          disabled: status.loading,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Original", children: "Original" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Light", children: "Light" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Dark", children: "Dark" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Custom", children: "Custom..." })
          ]
        }
      )
    ] }),
    settings.style === "Custom" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "textarea",
      {
        className: "w-full border rounded p-1",
        rows: 3,
        placeholder: "Describe your palette (e.g. 'pastel sunset')",
        value: settings.customDescription || "",
        onChange: (e) => setSettings((s) => ({ ...s, customDescription: e.target.value })),
        disabled: status.loading
      }
    ),
    status.error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-red-500 text-xs p-2 bg-red-50 rounded border border-red-200", children: [
      "Error: ",
      status.error
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        className: `w-full rounded py-1 ${status.loading ? "bg-gray-400 text-white cursor-not-allowed" : "bg-indigo-600 text-white hover:bg-indigo-700"}`,
        onClick: saveAndApply,
        disabled: status.loading,
        children: status.loading ? "Applying..." : "Apply"
      }
    )
  ] });
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}));
