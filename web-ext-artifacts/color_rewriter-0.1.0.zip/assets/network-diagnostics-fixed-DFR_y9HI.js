async function runNetworkDiagnostics(baseUrl = "http://127.0.0.1:11434") {
  try {
    const results = await browser.runtime.sendMessage({
      type: "NETWORK_DIAGNOSTICS",
      url: baseUrl
    });
    let success = false;
    let summary = "";
    if (results.success === false) {
      summary = "Diagnostics failed to run: " + (results.error || "Unknown error");
    } else if (results.tests?.directFetch?.success || results.tests?.alternateHost?.success) {
      success = true;
      summary = "Connection to Ollama server was successful. Server is reachable.";
      if (results.tests?.directFetch?.success) {
        summary += " Direct connection worked.";
      } else {
        summary += " Alternative host connection worked.";
      }
    } else {
      summary = "Failed to connect to Ollama server. Please check:\n1. Is Ollama running? Run 'ollama serve' in terminal.\n2. Try using http://localhost:11434 or http://127.0.0.1:11434\n3. Check if there's a firewall blocking the connection.";
    }
    return {
      success,
      results,
      summary
    };
  } catch (error) {
    return {
      success: false,
      results: { error: String(error) },
      summary: `Error running diagnostics: ${error instanceof Error ? error.message : String(error)}`
    };
  }
}

export { runNetworkDiagnostics };
