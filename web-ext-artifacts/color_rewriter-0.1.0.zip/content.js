console.log("Content script loaded at", (/* @__PURE__ */ new Date()).toISOString());
try {
  let collectColors2 = function() {
    const colors = /* @__PURE__ */ new Set();
    const treeWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    let node;
    while (node = treeWalker.nextNode()) {
      const cs = getComputedStyle(node);
      ["color", "backgroundColor", "borderColor"].forEach((prop) => {
        const val = cs[prop];
        if (val && !val.startsWith("rgba(0, 0, 0, 0)")) colors.add(val);
      });
    }
    return [...colors];
  }, applyColorMap2 = function(colorMap) {
    const existingStyle = document.getElementById("color-rewriter-style");
    if (existingStyle) existingStyle.remove();
    const rootStyle = document.createElement("style");
    rootStyle.id = "color-rewriter-root-style";
    rootStyle.textContent = `:root {
      ${Object.entries(colorMap).map(
      ([orig, replacement]) => `--cr-${orig.replace(/[^a-z0-9]/gi, "-")}: ${replacement};`
    ).join("\n")}
    }`;
    document.head.appendChild(rootStyle);
    function updateElementColors(element) {
      if (element instanceof HTMLElement) {
        const style = window.getComputedStyle(element);
        for (const [origColor, newColor] of Object.entries(colorMap)) {
          if (style.color === origColor) {
            element.style.setProperty("color", newColor, "important");
          }
          if (style.backgroundColor === origColor) {
            element.style.setProperty("background-color", newColor, "important");
          }
          if (style.borderColor === origColor) {
            element.style.setProperty("border-color", newColor, "important");
          }
        }
      }
    }
    const elements = document.querySelectorAll("*");
    elements.forEach(updateElementColors);
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach((node) => {
            if (node instanceof Element) {
              updateElementColors(node);
              const childElements = node.querySelectorAll("*");
              childElements.forEach(updateElementColors);
            }
          });
        }
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    console.log(`Applied ${Object.keys(colorMap).length} color replacements to the page`);
  };
  var collectColors = collectColors2, applyColorMap = applyColorMap2;
  browser.runtime.onMessage.addListener((message) => {
    console.log("Content script received message:", message);
    if (message.type === "GET_COLORS") {
      const colors = collectColors2();
      console.log(`Collected ${colors.length} colors from page`);
      return Promise.resolve({ colors });
    }
    if (message.type === "APPLY_MAP") {
      console.log("Applying color map to page:", message.payload);
      applyColorMap2(message.payload);
      return Promise.resolve({ success: true });
    }
    return true;
  });
  browser.runtime.sendMessage({
    type: "COLOR_SET",
    payload: collectColors2()
  }).catch((error) => {
    console.error("Failed to send message to background script:", error);
  });
} catch (error) {
  console.error("Content script error:", error);
}
