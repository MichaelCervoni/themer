async function saveDevKey(key) {
  if (!key || typeof key !== "string") {
    console.error("Please provide a valid API key string");
    return;
  }
  try {
    console.log("Attempting to save development API key...");
    const result = await browser.runtime.sendMessage({
      type: "SET_DEV_OPENAI_KEY",
      key
    });
    if (result.success) {
      console.log("✓ Development API key saved successfully!");
      console.log("You can now use OpenAI provider without setting a key in options.");
    } else {
      console.error("✗ Failed to save development API key:", result.error);
    }
  } catch (error) {
    console.error("✗ Error saving development API key:", error);
  }
}
async function checkDevKey() {
  try {
    const data = await browser.storage.local.get("DEV_OPENAI_KEY");
    if (data.DEV_OPENAI_KEY) {
      console.log("✓ Development API key is set");
      console.log("Key starts with:", data.DEV_OPENAI_KEY.substring(0, 5) + "...");
    } else {
      console.log("✗ No development API key is set");
      console.log('Use saveDevKey("your-key") to set one');
    }
  } catch (error) {
    console.error("Error checking development API key:", error);
  }
}
async function clearDevKey() {
  try {
    await browser.storage.local.remove("DEV_OPENAI_KEY");
    console.log("✓ Development API key cleared");
  } catch (error) {
    console.error("Error clearing development API key:", error);
  }
}
try {
  window.themer = {
    saveDevKey,
    checkDevKey,
    clearDevKey
  };
  window.saveDevKey = saveDevKey;
  window.checkDevKey = checkDevKey;
  window.clearDevKey = clearDevKey;
  console.log('[Themer] Development utilities loaded. Use saveDevKey("your-key") to store an OpenAI key.');
} catch (e) {
  console.warn("Could not expose development utilities on window:", e);
}

console.log("THEMER CONTENT SCRIPT: Script executing on " + window.location.href);
const originalInlineStyles = /* @__PURE__ */ new Map();
let currentObserver = null;
function isDarkTheme(colorMap) {
  let darkColorCount = 0;
  let totalColors = 0;
  for (const targetColor of Object.values(colorMap)) {
    if (!targetColor) continue;
    totalColors++;
    try {
      let r = 0, g = 0, b = 0;
      if (targetColor.startsWith("#")) {
        const hex = targetColor.replace("#", "");
        r = parseInt(hex.substring(0, 2), 16);
        g = parseInt(hex.substring(2, 4), 16);
        b = parseInt(hex.substring(4, 6), 16);
      } else if (targetColor.startsWith("rgb")) {
        const match = targetColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        if (match) {
          r = parseInt(match[1]);
          g = parseInt(match[2]);
          b = parseInt(match[3]);
        }
      }
      const brightness = (r * 299 + g * 587 + b * 114) / 1e3;
      if (brightness < 128) {
        darkColorCount++;
      }
    } catch (e) {
    }
  }
  return totalColors > 0 && darkColorCount / totalColors > 0.3;
}
function clearAppliedStyles() {
  console.log("CS: Clearing previously applied styles.");
  if (currentObserver) {
    currentObserver.disconnect();
    currentObserver = null;
  }
  originalInlineStyles.forEach((origStyles, element) => {
    if (!document.body || !document.body.contains(element)) {
      originalInlineStyles.delete(element);
      return;
    }
    if (origStyles.color !== void 0) element.style.color = origStyles.color;
    if (origStyles.backgroundColor !== void 0) element.style.backgroundColor = origStyles.backgroundColor;
    if (origStyles.borderColor !== void 0) element.style.borderColor = origStyles.borderColor;
    if (origStyles.borderTopColor !== void 0) element.style.borderTopColor = origStyles.borderTopColor;
    if (origStyles.borderRightColor !== void 0) element.style.borderRightColor = origStyles.borderRightColor;
    if (origStyles.borderBottomColor !== void 0) element.style.borderBottomColor = origStyles.borderBottomColor;
    if (origStyles.borderLeftColor !== void 0) element.style.borderLeftColor = origStyles.borderLeftColor;
  });
  originalInlineStyles.clear();
}
function applyColorMap(colorMap, semanticsFromBackground) {
  console.log(`CS (applyColorMap): Called. Received map with ${Object.keys(colorMap).length} keys.`);
  if (Object.keys(colorMap).length < 10 && Object.keys(colorMap).length > 0) {
    console.log("CS: Full colorMap:", colorMap);
  }
  clearAppliedStyles();
  if (Object.keys(colorMap).length === 0) {
    console.log("CS: Empty color map. Styles have been cleared. No new theme applied.");
    return;
  }
  const isDarkMode = isDarkTheme(colorMap);
  const styleElement = document.createElement("style");
  styleElement.id = "themer-global-styles";
  let cssRules = [];
  if (isDarkMode) {
    const darkBg = colorMap["rgb(255, 255, 255)"] || colorMap["#FFFFFF"] || colorMap["#FFF"] || colorMap["white"] || "#121212";
    const lightText = colorMap["rgb(0, 0, 0)"] || colorMap["#000000"] || colorMap["#000"] || colorMap["black"] || "#E0E0E0";
    const transparentBg = colorMap["rgba(0, 0, 0, 0)"] || colorMap["transparent"] || darkBg;
    console.log(`CS: Dark mode detected. Using base colors - Background: ${darkBg}, Text: ${lightText}, Transparent: ${transparentBg}`);
    cssRules.push(`
      /* Force dark theme basics */
      html, body {
        background-color: ${darkBg} !important;
        color: ${lightText} !important;
      }
    `);
    cssRules.push(`
      /* Dark mode fallbacks for text (catch black text not explicitly mapped) */
      p, span, div, h1, h2, h3, h4, h5, h6, a, li, td, th, label, input, textarea {
        color: ${lightText} !important;
      }
      
      /* Handle search input text */
      input[type="text"], input[type="search"], input:not([type]) {
        color: ${lightText} !important;
        background-color: #2A2A2A !important;
      }
      
      /* Force contrast for links */
      a:link, a:visited {
        color: #8CB4FF !important;
      }
    `);
    cssRules.push(`
      /* CSS Variable overrides for dark mode */
      :root {
        --text-color: ${lightText} !important;
        --body-color: ${lightText} !important;
        --body-bg: ${darkBg} !important;
        --bg-color: ${darkBg} !important;
        --background: ${darkBg} !important;
        --background-color: ${darkBg} !important;
        
        /* Material & Bootstrap variables */
        --mat-background-color: ${darkBg} !important;
        --bs-body-bg: ${darkBg} !important;
        --bs-body-color: ${lightText} !important;
      }
    `);
  }
  if (isDarkMode) {
    const transparentMapping = colorMap["rgba(0, 0, 0, 0)"] || colorMap["transparent"];
    if (transparentMapping) {
      cssRules.push(`
        /* Handle elements with transparent backgrounds */
        [style*="background-color: transparent"],
        [style*="background-color: rgba(0, 0, 0, 0)"],
        [style*="background: transparent"],
        [style*="background: rgba(0, 0, 0, 0)"] {
          background-color: ${transparentMapping} !important;
        }
      `);
    }
  }
  const varFallbacksToOverride = semanticsFromBackground?.varFallbacks || [];
  if (varFallbacksToOverride.length > 0) {
    let varOverrideCss = ":root {\n";
    const overriddenVars = /* @__PURE__ */ new Set();
    varFallbacksToOverride.forEach((item) => {
      const mappedFallbackColor = colorMap[item.fallbackColor];
      if (mappedFallbackColor && !overriddenVars.has(item.varName)) {
        varOverrideCss += `  ${item.varName}: ${mappedFallbackColor} !important; /* Original fallback: ${item.fallbackColor} */
`;
        overriddenVars.add(item.varName);
      }
    });
    varOverrideCss += "}";
    if (overriddenVars.size > 0) {
      cssRules.push(varOverrideCss);
      console.log("CS: Added CSS variable overrides for fallbacks:", overriddenVars.size);
    }
  }
  Object.entries(colorMap).forEach(([origColor, newColor]) => {
    if (!origColor || !newColor) return;
    const cleanOrig = origColor.replace(/\s+/g, " ").trim();
    const colorId = origColor.replace(/[^a-z0-9]/gi, "-");
    cssRules.push(`
      /* Color replacements for ${cleanOrig} */
      [style*="color: ${cleanOrig}"] { color: ${newColor} !important; }
      [style*="background-color: ${cleanOrig}"] { background-color: ${newColor} !important; }
      [style*="background: ${cleanOrig}"] { background: ${newColor} !important; }
      [style*="border-color: ${cleanOrig}"] { border-color: ${newColor} !important; }
      [style*="border: ${cleanOrig}"] { border-color: ${newColor} !important; }
      
      /* Target elements that might use this color but aren't caught by attribute selectors */
      .themer-force-${colorId} { color: ${newColor} !important; background-color: ${newColor} !important; }
    `);
  });
  if (isDarkMode) {
    cssRules.push(`
      /* Common element type selectors */
      input, textarea, select, button {
        background-color: #2A2A2A !important;
        color: #E0E0E0 !important;
        border-color: #444 !important;
      }
    `);
  }
  styleElement.textContent = cssRules.join("\n");
  const observer = new MutationObserver(() => {
    if (!document.head.contains(styleElement)) {
      console.log("CS: Style element was removed, re-adding it");
      document.head.appendChild(styleElement);
    }
  });
  document.head.appendChild(styleElement);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  currentObserver = observer;
  applyInlineStyles(colorMap);
  console.log("CS: Global theme styles applied successfully");
}
function applyInlineStyles(colorMap) {
  console.log("CS: Applying inline styles for better coverage");
  const elementsToProcess = [
    document.documentElement,
    document.body,
    ...Array.from(document.querySelectorAll("div, main, article, section, header, footer, aside"))
  ];
  elementsToProcess.forEach((element) => {
    if (!(element instanceof HTMLElement)) return;
    const htmlElement = element;
    const computedStyle = getComputedStyle(htmlElement);
    const bgColor = computedStyle.backgroundColor;
    const newBgColor = colorMap[bgColor];
    if (newBgColor) {
      const origStyle = originalInlineStyles.get(htmlElement) || {};
      if (origStyle.backgroundColor === void 0) {
        origStyle.backgroundColor = htmlElement.style.backgroundColor || "";
      }
      htmlElement.style.setProperty("background-color", newBgColor, "important");
      originalInlineStyles.set(htmlElement, origStyle);
    }
    const textColor = computedStyle.color;
    const newTextColor = colorMap[textColor];
    if (newTextColor) {
      const origStyle = originalInlineStyles.get(htmlElement) || {};
      if (origStyle.color === void 0) {
        origStyle.color = htmlElement.style.color || "";
      }
      htmlElement.style.setProperty("color", newTextColor, "important");
      originalInlineStyles.set(htmlElement, origStyle);
    }
  });
}
function isColorString(str) {
  if (!str) return false;
  if (typeof str !== "string") {
    console.warn("THEMER: Non-string value passed to isColorString:", str);
    return false;
  }
  const s = str.toLowerCase().trim();
  if (s === "transparent" || s === "inherit" || s === "initial" || s === "currentcolor" || s.includes("var(")) return false;
  return s.startsWith("#") || s.startsWith("rgb") || s.startsWith("hsl") || /^[a-z]+(-[a-z]+)*$/.test(s);
}
function extractColorsFromStylesheets() {
  const colorsToMap = /* @__PURE__ */ new Set();
  const varFallbacks = [];
  const cssVarPattern = /var\(\s*(--[^,\s)]+)\s*(?:,\s*([^)]+))?\)/g;
  const styleSheetsArray = Array.from(document.styleSheets);
  for (const sheet of styleSheetsArray) {
    try {
      if (sheet.href && !sheet.href.startsWith(window.location.origin) && !sheet.href.startsWith("blob:") && !sheet.href.startsWith("data:")) {
        try {
          if (!sheet.cssRules && !sheet.rules) continue;
        } catch (e) {
          continue;
        }
      }
      const rules = sheet.cssRules || sheet.rules;
      if (!rules) continue;
      const rulesArray = Array.from(rules);
      for (const rule of rulesArray) {
        if (rule instanceof CSSStyleRule) {
          const style = rule.style;
          for (let k = 0; k < style.length; k++) {
            const propName = style[k];
            if (!propName.includes("color") && !propName.includes("background") && !propName.includes("border") && !propName.includes("shadow") && !propName.includes("fill") && !propName.includes("stroke")) {
              continue;
            }
            const propValue = style.getPropertyValue(propName);
            if (propValue) {
              let match;
              cssVarPattern.lastIndex = 0;
              let hasVar = false;
              while ((match = cssVarPattern.exec(propValue)) !== null) {
                hasVar = true;
                const varName = match[1].trim();
                const fallbackColor = match[2] ? match[2].trim() : null;
                if (fallbackColor && isColorString(fallbackColor)) {
                  colorsToMap.add(fallbackColor);
                  if (!varFallbacks.some((vf) => vf.varName === varName && vf.fallbackColor === fallbackColor)) {
                    varFallbacks.push({ varName, fallbackColor });
                  }
                }
              }
              if (!hasVar || propValue.replace(cssVarPattern, "").trim() !== "") {
                const potentialDirectColor = propValue.trim();
                if (!potentialDirectColor.startsWith("var(") && isColorString(potentialDirectColor)) {
                  colorsToMap.add(potentialDirectColor);
                }
              }
            }
          }
        }
      }
    } catch (e) {
    }
  }
  return { colorsToMap, varFallbacks };
}
function collectColorsWithSemantics() {
  console.log("CS (collectColorsWithSemantics): Starting color and semantic collection.");
  const allColors = /* @__PURE__ */ new Set();
  const backgroundColors = /* @__PURE__ */ new Set();
  const textColors = /* @__PURE__ */ new Set();
  const borderColors = /* @__PURE__ */ new Set();
  const accentColors = /* @__PURE__ */ new Set();
  const linkColors = /* @__PURE__ */ new Set();
  const transparentColors = /* @__PURE__ */ new Set();
  const trueBackgrounds = /* @__PURE__ */ new Map();
  const colorRelationships = [];
  if (document.documentElement) {
    const htmlStyle = getComputedStyle(document.documentElement);
    const htmlBgColor = htmlStyle.backgroundColor;
    if (isColorString(htmlBgColor)) {
      allColors.add(htmlBgColor);
      backgroundColors.add(htmlBgColor);
      if (htmlBgColor === "transparent" || htmlBgColor === "rgba(0, 0, 0, 0)") {
        transparentColors.add(htmlBgColor);
        trueBackgrounds.set(htmlBgColor, "rgb(255, 255, 255)");
      }
    }
  }
  if (document.body) {
    const bodyStyle = getComputedStyle(document.body);
    const bodyBgColor = bodyStyle.backgroundColor;
    if (isColorString(bodyBgColor)) {
      allColors.add(bodyBgColor);
      backgroundColors.add(bodyBgColor);
      if (bodyBgColor === "transparent" || bodyBgColor === "rgba(0, 0, 0, 0)") {
        transparentColors.add(bodyBgColor);
        const actualHtmlBg = document.documentElement ? getComputedStyle(document.documentElement).backgroundColor : "rgb(255, 255, 255)";
        const trueBodyBg = isColorString(actualHtmlBg) && actualHtmlBg !== "transparent" && actualHtmlBg !== "rgba(0, 0, 0, 0)" ? actualHtmlBg : "rgb(255, 255, 255)";
        trueBackgrounds.set(bodyBgColor, trueBodyBg);
      }
    }
  }
  const selectorsForRelationships = [
    "body",
    "main",
    "article",
    "section",
    "header",
    "footer",
    "nav",
    "aside",
    "h1",
    "h2",
    "h3",
    "p",
    "a",
    "button",
    'input[type="text"]',
    'input[type="submit"]',
    ".card",
    ".container",
    ".content",
    // Common layout classes
    '[role="banner"]',
    '[role="main"]',
    '[role="navigation"]',
    '[role="contentinfo"]'
  ];
  const importantElements = [];
  selectorsForRelationships.forEach((selector) => {
    try {
      document.querySelectorAll(selector).forEach((el) => {
        if (el instanceof HTMLElement && el.offsetParent !== null) {
          importantElements.push(el);
        }
      });
    } catch (e) {
    }
  });
  const uniqueImportantElements = Array.from(new Set(importantElements)).slice(0, 50);
  uniqueImportantElements.forEach((element) => {
    const computedStyle = getComputedStyle(element);
    const textColor = computedStyle.color;
    let originalBgColor = computedStyle.backgroundColor;
    let effectiveBgColor = originalBgColor;
    let isTransparentBg = false;
    if (isColorString(textColor)) {
      allColors.add(textColor);
      textColors.add(textColor);
      if (element.tagName === "A" && element.closest("nav, header, footer")) {
        linkColors.add(textColor);
      }
    }
    if (isColorString(originalBgColor)) {
      allColors.add(originalBgColor);
      backgroundColors.add(originalBgColor);
      if (originalBgColor === "transparent" || originalBgColor === "rgba(0, 0, 0, 0)") {
        isTransparentBg = true;
        transparentColors.add(originalBgColor);
        const trueBg = getActualBackgroundColor(element);
        trueBackgrounds.set(originalBgColor, trueBg);
        if (isColorString(trueBg)) {
          allColors.add(trueBg);
          backgroundColors.add(trueBg);
        }
        effectiveBgColor = trueBg;
      }
    }
    const borderColor = computedStyle.borderColor;
    if (isColorString(borderColor) && borderColor !== textColor && borderColor !== effectiveBgColor) {
      allColors.add(borderColor);
      borderColors.add(borderColor);
    }
    if (isColorString(textColor) && isColorString(effectiveBgColor)) {
      const relationshipExists = colorRelationships.some(
        (r) => r.text === textColor && r.background === effectiveBgColor && r.element === element.tagName.toLowerCase()
      );
      if (!relationshipExists || colorRelationships.length < 5) {
        colorRelationships.push({
          text: textColor,
          background: effectiveBgColor,
          // Use the resolved background
          element: element.tagName.toLowerCase() + (element.id ? `#${element.id}` : "") + (element.className && typeof element.className === "string" ? `.${element.className.split(" ").join(".")}` : ""),
          transparent: isTransparentBg
          // Was the element's OWN background transparent?
        });
      }
    }
  });
  const sheetData = extractColorsFromStylesheets();
  sheetData.colorsToMap.forEach((color) => {
    if (isColorString(color)) {
      allColors.add(color);
      if (!textColors.has(color) && !backgroundColors.has(color) && !borderColors.has(color)) {
        accentColors.add(color);
      }
    }
  });
  const finalSemantics = {
    backgroundColors: Array.from(new Set([...backgroundColors, ...sheetData.colorsToMap.values()].filter((c) => !textColors.has(c) || backgroundColors.has(c)))),
    // Prioritize as BG if ambiguous
    textColors: Array.from(textColors),
    borderColors: Array.from(borderColors),
    accentColors: Array.from(accentColors),
    // Colors that weren't clearly text or main backgrounds
    linkColors: Array.from(linkColors),
    transparentColors: Array.from(transparentColors),
    // Original transparent strings
    trueBackgrounds: Object.fromEntries(trueBackgrounds),
    // Map of transparent string to its resolved solid color string
    relationships: colorRelationships.slice(0, 15),
    // Limit to a reasonable number for the prompt
    varFallbacks: sheetData.varFallbacks || []
    // From extractColorsFromStylesheets
  };
  Object.values(finalSemantics).forEach((category) => {
    if (Array.isArray(category)) {
      category.forEach((color) => {
        if (isColorString(color)) allColors.add(color);
      });
    } else if (typeof category === "object" && category !== null && !Array.isArray(category)) {
      Object.values(category).forEach((color) => {
        if (isColorString(color)) allColors.add(color);
      });
    }
  });
  const finalColorsArray = Array.from(allColors).filter((c) => isColorString(c));
  console.log(`CS (collectColorsWithSemantics): Collected ${finalColorsArray.length} unique valid colors. Relationships: ${finalSemantics.relationships.length}. VarFallbacks: ${finalSemantics.varFallbacks.length}.`);
  if (finalColorsArray.length < 20) ;
  return {
    colors: finalColorsArray,
    semantics: finalSemantics
  };
}
function getActualBackgroundColor(element) {
  const computedStyle = window.getComputedStyle(element);
  const bgColor = computedStyle.backgroundColor;
  if (bgColor === "rgba(0, 0, 0, 0)" || bgColor === "transparent") {
    let currentElement = element.parentElement;
    while (currentElement) {
      const parentBgColor = window.getComputedStyle(currentElement).backgroundColor;
      if (parentBgColor !== "rgba(0, 0, 0, 0)" && parentBgColor !== "transparent") {
        return parentBgColor;
      }
      currentElement = currentElement.parentElement;
    }
    const htmlBg = window.getComputedStyle(document.documentElement).backgroundColor;
    if (htmlBg !== "rgba(0, 0, 0, 0)" && htmlBg !== "transparent") {
      return htmlBg;
    }
    const bodyBg = window.getComputedStyle(document.body).backgroundColor;
    if (bodyBg !== "rgba(0, 0, 0, 0)" && bodyBg !== "transparent") {
      return bodyBg;
    }
    return "rgb(255, 255, 255)";
  }
  return bgColor;
}
let lastMessageProcessedTime = 0;
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    const now = Date.now();
    if (now - lastMessageProcessedTime < 50 && message.type === "GET_COLORS") {
      console.log(`THEMER: Duplicate ${message.type} message detected and ignored (${now - lastMessageProcessedTime}ms)`);
      sendResponse({ success: false, error: "Duplicate message" });
      return true;
    }
    lastMessageProcessedTime = now;
    console.log(`THEMER: Received message: ${message.type}`, message);
    if (message.type === "APPLY_MAP") {
      console.log(`THEMER: Applying color map with ${Object.keys(message.payload).length} colors`);
      applyColorMap(message.payload, message.semantics);
      sendResponse({ success: true });
      return true;
    }
    if (message.type === "GET_COLORS") {
      console.log("THEMER: Processing GET_COLORS request...");
      if (window.location.hostname.includes("amazon")) {
        const indicator = document.createElement("div");
        indicator.id = "themer-processing-indicator";
        indicator.style.cssText = "position:fixed;top:0;left:0;background:blue;color:white;padding:2px 5px;z-index:999999;font-size:10px;";
        indicator.textContent = "Themer Processing";
        document.body ? document.body.appendChild(indicator) : document.documentElement.appendChild(indicator);
      }
      try {
        const colorInfo = collectColorsWithSemantics();
        console.log("THEMER: Sending colors:", colorInfo.colors.length);
        const indicator = document.getElementById("themer-processing-indicator");
        if (indicator && indicator.parentNode) {
          indicator.parentNode.removeChild(indicator);
        }
        sendResponse({
          colors: colorInfo.colors,
          semantics: colorInfo.semantics
        });
      } catch (colorError) {
        console.error("THEMER: Error collecting colors:", colorError);
        sendResponse({ success: false, error: `Error collecting colors: ${String(colorError)}` });
      }
      return true;
    }
    if (message.type === "VERIFY_CONTENT_SCRIPT") {
      console.log("THEMER: Content script verification requested");
      verifyContentScriptRunning();
      sendResponse({ success: true, timestamp: Date.now() });
      return true;
    }
    console.warn("THEMER: Unknown message type:", message.type);
    sendResponse({ success: false, error: "Unknown message type" });
    return true;
  } catch (error) {
    console.error("THEMER: Error handling message:", error);
    sendResponse({ success: false, error: String(error) });
    return true;
  }
});
setTimeout(() => {
  try {
    console.log("THEMER CONTENT SCRIPT: Sending test message to background");
    browser.runtime.sendMessage({
      type: "CONTENT_SCRIPT_LOADED",
      url: window.location.href,
      timestamp: Date.now()
    }).then((response) => {
      console.log("THEMER CONTENT SCRIPT: Got response from background:", response);
    }).catch((error) => {
      console.error("THEMER CONTENT SCRIPT: Error sending test message:", error);
    });
  } catch (e) {
    console.error("THEMER CONTENT SCRIPT: Error in test communication:", e);
  }
}, 1e3);
async function applyInitialTheme() {
  try {
    console.log("CS (applyInitialTheme): Function called. Requesting initial theme settings from background.");
    const activeSettings = await browser.runtime.sendMessage({ type: "GET_ACTIVE_SETTINGS_FOR_TLD" });
    console.log("CS (applyInitialTheme): Received response:", activeSettings ? `Style: ${activeSettings.style}, palette items: ${Object.keys(activeSettings.palette || {}).length}` : "null");
    if (activeSettings && activeSettings.palette && Object.keys(activeSettings.palette).length > 0) {
      console.log(`CS (applyInitialTheme): Applying initial theme. Style: ${activeSettings.style}`);
      applyColorMap(activeSettings.palette, activeSettings.semantics);
    } else {
      console.log("CS (applyInitialTheme): No active theme found. Applying empty map.");
      applyColorMap({}, null);
    }
  } catch (error) {
    console.error("CS (applyInitialTheme): Error:", error);
    if (error.message.includes("Receiving end does not exist")) {
      console.warn("CS (applyInitialTheme): Background script not ready yet.");
    }
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    console.log("CS: DOMContentLoaded. Sending colors and applying initial theme.");
    if (document.body) {
      const colorInfo = collectColorsWithSemantics();
      browser.runtime.sendMessage({
        type: "COLOR_SET",
        payload: colorInfo.colors,
        semantics: colorInfo.semantics
      }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
    }
    applyInitialTheme();
  });
} else {
  console.log("CS: Document already loaded. Sending colors and applying initial theme.");
  if (document.body) {
    const colorInfo = collectColorsWithSemantics();
    browser.runtime.sendMessage({
      type: "COLOR_SET",
      payload: colorInfo.colors,
      semantics: colorInfo.semantics
    }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
  }
  applyInitialTheme();
}
try {
  const isDev = browser.runtime.getManifest().version.includes("dev") || browser.runtime.getManifest().version === "0.1.0";
  if (isDev) {
    console.log("[Themer] Running in development mode");
    window.themer = {
      saveDevKey: saveDevKey,
      checkDevKey: checkDevKey,
      clearDevKey: clearDevKey
    };
    console.log('[Themer] Development utilities available. Use window.themer.saveDevKey("your-key")');
  }
} catch (e) {
  console.debug("[Themer] Could not initialize development utilities:", e);
}
function verifyContentScriptRunning() {
  console.log("THEMER CONTENT SCRIPT: verifyContentScriptRunning called");
  const indicator = document.createElement("div");
  indicator.id = "themer-content-script-indicator";
  indicator.style.cssText = "position:fixed;top:0;right:0;background:red;color:white;padding:2px 5px;z-index:999999;font-size:10px;";
  indicator.textContent = "Themer Active";
  document.body ? document.body.appendChild(indicator) : document.documentElement.appendChild(indicator);
  setTimeout(() => {
    if (indicator && indicator.parentNode) {
      indicator.parentNode.removeChild(indicator);
    }
  }, 5e3);
}
if (window.location.hostname.includes("amazon")) {
  setTimeout(verifyContentScriptRunning, 500);
}
function enableDebugMode() {
  const debugPanel = document.createElement("div");
  debugPanel.style.cssText = "position:fixed;bottom:0;right:0;background:rgba(0,0,0,0.8);color:white;padding:10px;z-index:999999;font-size:12px;max-height:30vh;overflow:auto;";
  debugPanel.textContent = "Themer Debug:";
  document.body.appendChild(debugPanel);
  window.themerDebug = (msg, data) => {
    const logItem = document.createElement("div");
    logItem.textContent = `${(/* @__PURE__ */ new Date()).toLocaleTimeString()}: ${msg}`;
    if (data) {
      console.log(`THEMER DEBUG: ${msg}`, data);
    }
    debugPanel.appendChild(logItem);
    while (debugPanel.childNodes.length > 21) {
      if (debugPanel.childNodes[1]) {
        debugPanel.removeChild(debugPanel.childNodes[1]);
      } else {
        break;
      }
    }
  };
  if (window.themerDebug) {
    window.themerDebug("Debug mode enabled");
  }
}
if (window.location.search.includes("themer-debug=1")) {
  setTimeout(enableDebugMode, 1e3);
}
(function() {
  console.log("CS: Content script initialization complete");
  if (window.location.search.includes("themer-verify=1")) {
    verifyContentScriptRunning();
  }
})();
