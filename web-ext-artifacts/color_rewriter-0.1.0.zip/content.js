async function saveDevKey(key) {
  if (!key || typeof key !== "string") {
    console.error("Please provide a valid API key string");
    return;
  }
  try {
    console.log("Attempting to save development API key...");
    const result = await browser.runtime.sendMessage({
      type: "SET_DEV_OPENAI_KEY",
      key
    });
    if (result.success) {
      console.log("✓ Development API key saved successfully!");
      console.log("You can now use OpenAI provider without setting a key in options.");
    } else {
      console.error("✗ Failed to save development API key:", result.error);
    }
  } catch (error) {
    console.error("✗ Error saving development API key:", error);
  }
}
async function checkDevKey() {
  try {
    const data = await browser.storage.local.get("DEV_OPENAI_KEY");
    if (data.DEV_OPENAI_KEY) {
      console.log("✓ Development API key is set");
      console.log("Key starts with:", data.DEV_OPENAI_KEY.substring(0, 5) + "...");
    } else {
      console.log("✗ No development API key is set");
      console.log('Use saveDevKey("your-key") to set one');
    }
  } catch (error) {
    console.error("Error checking development API key:", error);
  }
}
async function clearDevKey() {
  try {
    await browser.storage.local.remove("DEV_OPENAI_KEY");
    console.log("✓ Development API key cleared");
  } catch (error) {
    console.error("Error clearing development API key:", error);
  }
}
try {
  window.themer = window.themer || {};
  window.themer.saveDevKey = saveDevKey;
  window.themer.checkDevKey = checkDevKey;
  window.themer.clearDevKey = clearDevKey;
  window.saveDevKey = saveDevKey;
  window.checkDevKey = checkDevKey;
  window.clearDevKey = clearDevKey;
  console.log('[Themer] Development utilities loaded. Use saveDevKey("your-key") to store an OpenAI key.');
} catch (e) {
  console.warn("Could not expose development utilities on window:", e);
}

console.log("CS: Content script loaded at", (/* @__PURE__ */ new Date()).toISOString());
const originalInlineStyles = /* @__PURE__ */ new Map();
let currentObserver = null;
function clearAppliedStyles() {
  console.log("CS: Clearing previously applied styles.");
  if (currentObserver) {
    currentObserver.disconnect();
    currentObserver = null;
  }
  originalInlineStyles.forEach((origStyles, element) => {
    if (!document.body || !document.body.contains(element)) {
      originalInlineStyles.delete(element);
      return;
    }
    if (origStyles.color !== void 0) element.style.color = origStyles.color;
    if (origStyles.backgroundColor !== void 0) element.style.backgroundColor = origStyles.backgroundColor;
    if (origStyles.borderColor !== void 0) element.style.borderColor = origStyles.borderColor;
    if (origStyles.borderTopColor !== void 0) element.style.borderTopColor = origStyles.borderTopColor;
    if (origStyles.borderRightColor !== void 0) element.style.borderRightColor = origStyles.borderRightColor;
    if (origStyles.borderBottomColor !== void 0) element.style.borderBottomColor = origStyles.borderBottomColor;
    if (origStyles.borderLeftColor !== void 0) element.style.borderLeftColor = origStyles.borderLeftColor;
  });
  originalInlineStyles.clear();
}
function collectColors() {
  const colors = /* @__PURE__ */ new Set();
  if (!document.body) return [];
  const treeWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
  let node;
  while (node = treeWalker.nextNode()) {
    if (node.tagName === "SCRIPT" || node.tagName === "STYLE" || node.tagName === "NOSCRIPT") continue;
    const cs = getComputedStyle(node);
    const propsToCollect = ["color", "backgroundColor", "borderColor", "borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"];
    propsToCollect.forEach((prop) => {
      const colorValue = cs.getPropertyValue(prop);
      if (colorValue && colorValue !== "transparent" && colorValue !== "rgba(0, 0, 0, 0)" && colorValue !== "none" && !colorValue.startsWith("var(")) {
        colors.add(colorValue);
      }
    });
  }
  if (document.documentElement) {
    const csHtml = getComputedStyle(document.documentElement);
    const propsToCollectHtml = ["color", "backgroundColor"];
    propsToCollectHtml.forEach((prop) => {
      const colorValue = csHtml.getPropertyValue(prop);
      if (colorValue && colorValue !== "transparent" && colorValue !== "rgba(0, 0, 0, 0)" && colorValue !== "none" && !colorValue.startsWith("var(")) {
        colors.add(colorValue);
      }
    });
  }
  console.log(`CS (collectColors): Collected ${colors.size} unique colors.`);
  return [...colors];
}
function applyColorMap(colorMap) {
  console.log(`CS (applyColorMap): Called. Received map with ${Object.keys(colorMap).length} keys.`);
  if (Object.keys(colorMap).length < 10 && Object.keys(colorMap).length > 0) {
    console.log("CS: Full colorMap:", colorMap);
  }
  clearAppliedStyles();
  if (Object.keys(colorMap).length === 0) {
    console.log("CS: Empty color map. Styles have been cleared. No new theme applied.");
    return;
  }
  console.log("CS: Applying new color map.");
  function processElement(element) {
    if (!(element instanceof HTMLElement) || element.tagName === "SCRIPT" || element.tagName === "STYLE" || element.tagName === "NOSCRIPT") {
      return;
    }
    const htmlElement = element;
    const computedStyle = getComputedStyle(htmlElement);
    const propertiesToProcess = [
      { computed: computedStyle.color, inlineProp: "color" },
      { computed: computedStyle.backgroundColor, inlineProp: "backgroundColor" },
      { computed: computedStyle.borderColor, inlineProp: "borderColor" },
      { computed: computedStyle.borderTopColor, inlineProp: "borderTopColor" },
      { computed: computedStyle.borderRightColor, inlineProp: "borderRightColor" },
      { computed: computedStyle.borderBottomColor, inlineProp: "borderBottomColor" },
      { computed: computedStyle.borderLeftColor, inlineProp: "borderLeftColor" }
    ];
    const originalStylesForThisElement = originalInlineStyles.get(htmlElement) || {};
    let modifiedOriginals = false;
    propertiesToProcess.forEach((item) => {
      const newColor = colorMap[item.computed];
      if (item.inlineProp === "backgroundColor" && (htmlElement === document.body || htmlElement === document.documentElement)) {
        console.log(`CS_DEBUG: BGColor Check for ${htmlElement.tagName}:`, {
          originalColor: item.computed,
          hasMapping: newColor ? true : false,
          newColor: newColor || "none"
        });
      }
      if (newColor && item.computed !== newColor) {
        if (originalStylesForThisElement[item.inlineProp] === void 0) {
          originalStylesForThisElement[item.inlineProp] = htmlElement.style[item.inlineProp] || "";
          modifiedOriginals = true;
        }
        htmlElement.style.setProperty(item.inlineProp, newColor, "important");
      }
    });
    if (modifiedOriginals) {
      originalInlineStyles.set(htmlElement, originalStylesForThisElement);
    }
  }
  if (document.documentElement) processElement(document.documentElement);
  if (document.body) {
    processElement(document.body);
    document.querySelectorAll("body *").forEach((el) => processElement(el));
  }
  currentObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          processElement(node);
          node.querySelectorAll("*").forEach((childEl) => processElement(childEl));
        }
      });
    });
  });
  if (document.documentElement) {
    currentObserver.observe(document.documentElement, { childList: true, subtree: true });
  }
  console.log("CS: Color map applied and observer set up.");
}
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(`CS: Received message: ${message.type}`);
  if (message.type === "APPLY_MAP") {
    console.log(`CS (APPLY_MAP handler): Received APPLY_MAP. Payload items: ${message.payload ? Object.keys(message.payload).length : "(no payload)"}. Applying...`);
    applyColorMap(message.payload);
    sendResponse({ success: true });
    return true;
  }
  if (message.type === "GET_COLORS") {
    const colors = collectColors();
    console.log("CS (GET_COLORS handler): Sending colors:", colors.length);
    sendResponse({ colors });
    return true;
  }
  console.warn("CS: Unknown message type received by content script:", message.type);
  return false;
});
async function applyInitialTheme() {
  try {
    console.log("CS (applyInitialTheme): Function called. Requesting initial theme settings from background.");
    const activeSettings = await browser.runtime.sendMessage({ type: "GET_ACTIVE_SETTINGS_FOR_TLD" });
    console.log("CS (applyInitialTheme): Received response:", activeSettings ? `Style: ${activeSettings.style}, palette items: ${Object.keys(activeSettings.palette || {}).length}` : "null");
    if (activeSettings && activeSettings.palette && Object.keys(activeSettings.palette).length > 0) {
      console.log(`CS (applyInitialTheme): Applying initial theme. Style: ${activeSettings.style}`);
      applyColorMap(activeSettings.palette);
    } else {
      console.log("CS (applyInitialTheme): No active theme found. Applying empty map.");
      applyColorMap({});
    }
  } catch (error) {
    console.error("CS (applyInitialTheme): Error:", error);
    if (error.message.includes("Receiving end does not exist")) {
      console.warn("CS (applyInitialTheme): Background script not ready yet.");
    }
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    console.log("CS: DOMContentLoaded. Sending colors and applying initial theme.");
    if (document.body) {
      browser.runtime.sendMessage({ type: "COLOR_SET", payload: collectColors() }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
    }
    applyInitialTheme();
  });
} else {
  console.log("CS: Document already loaded. Sending colors and applying initial theme.");
  if (document.body) {
    browser.runtime.sendMessage({ type: "COLOR_SET", payload: collectColors() }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
  }
  applyInitialTheme();
}
try {
  const isDev = browser.runtime.getManifest().version.includes("dev") || browser.runtime.getManifest().version === "0.1.0";
  if (isDev) {
    console.log("[Themer] Running in development mode");
    window.themer = window.themer || {};
    window.themer.saveDevKey = saveDevKey;
    window.themer.checkDevKey = checkDevKey;
    window.themer.clearDevKey = clearDevKey;
    console.log('[Themer] Development utilities available. Use window.themer.saveDevKey("your-key")');
  }
} catch (e) {
  console.debug("[Themer] Could not initialize development utilities:", e);
}
