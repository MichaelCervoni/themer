async function saveDevKey(key) {
  if (!key || typeof key !== "string") {
    console.error("Please provide a valid API key string");
    return;
  }
  try {
    console.log("Attempting to save development API key...");
    const result = await browser.runtime.sendMessage({
      type: "SET_DEV_OPENAI_KEY",
      key
    });
    if (result.success) {
      console.log("✓ Development API key saved successfully!");
      console.log("You can now use OpenAI provider without setting a key in options.");
    } else {
      console.error("✗ Failed to save development API key:", result.error);
    }
  } catch (error) {
    console.error("✗ Error saving development API key:", error);
  }
}
async function checkDevKey() {
  try {
    const data = await browser.storage.local.get("DEV_OPENAI_KEY");
    if (data.DEV_OPENAI_KEY) {
      console.log("✓ Development API key is set");
      console.log("Key starts with:", data.DEV_OPENAI_KEY.substring(0, 5) + "...");
    } else {
      console.log("✗ No development API key is set");
      console.log('Use saveDevKey("your-key") to set one');
    }
  } catch (error) {
    console.error("Error checking development API key:", error);
  }
}
async function clearDevKey() {
  try {
    await browser.storage.local.remove("DEV_OPENAI_KEY");
    console.log("✓ Development API key cleared");
  } catch (error) {
    console.error("Error clearing development API key:", error);
  }
}
try {
  window.themer = window.themer || {};
  window.themer.saveDevKey = saveDevKey;
  window.themer.checkDevKey = checkDevKey;
  window.themer.clearDevKey = clearDevKey;
  window.saveDevKey = saveDevKey;
  window.checkDevKey = checkDevKey;
  window.clearDevKey = clearDevKey;
  console.log('[Themer] Development utilities loaded. Use saveDevKey("your-key") to store an OpenAI key.');
} catch (e) {
  console.warn("Could not expose development utilities on window:", e);
}

console.log("THEMER CONTENT SCRIPT: Loaded at", (/* @__PURE__ */ new Date()).toISOString());
console.log("THEMER CONTENT SCRIPT: browser.runtime available:", !!browser.runtime);
(function checkContentScriptExecution() {
  console.log("CS: Content script initialized for", window.location.href);
  try {
    browser.runtime.sendMessage({
      type: "CONTENT_SCRIPT_LOADED",
      url: window.location.href
    }).catch((err) => console.error("CS: Error sending initial message:", err));
  } catch (e) {
    console.error("CS: Error in initialization:", e);
  }
})();
console.log("CS: Content script loaded at", (/* @__PURE__ */ new Date()).toISOString());
console.log("CS: Content script LOADED at", (/* @__PURE__ */ new Date()).toISOString());
const originalInlineStyles = /* @__PURE__ */ new Map();
let currentObserver = null;
function isDarkTheme(colorMap) {
  let darkColorCount = 0;
  let totalColors = 0;
  for (const targetColor of Object.values(colorMap)) {
    if (!targetColor) continue;
    totalColors++;
    try {
      let r = 0, g = 0, b = 0;
      if (targetColor.startsWith("#")) {
        const hex = targetColor.replace("#", "");
        r = parseInt(hex.substring(0, 2), 16);
        g = parseInt(hex.substring(2, 4), 16);
        b = parseInt(hex.substring(4, 6), 16);
      } else if (targetColor.startsWith("rgb")) {
        const match = targetColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        if (match) {
          r = parseInt(match[1]);
          g = parseInt(match[2]);
          b = parseInt(match[3]);
        }
      }
      const brightness = (r * 299 + g * 587 + b * 114) / 1e3;
      if (brightness < 80) {
        darkColorCount++;
      }
    } catch (e) {
    }
  }
  return totalColors > 0 && darkColorCount / totalColors > 0.3;
}
function clearAppliedStyles() {
  console.log("CS: Clearing previously applied styles.");
  if (currentObserver) {
    currentObserver.disconnect();
    currentObserver = null;
  }
  originalInlineStyles.forEach((origStyles, element) => {
    if (!document.body || !document.body.contains(element)) {
      originalInlineStyles.delete(element);
      return;
    }
    if (origStyles.color !== void 0) element.style.color = origStyles.color;
    if (origStyles.backgroundColor !== void 0) element.style.backgroundColor = origStyles.backgroundColor;
    if (origStyles.borderColor !== void 0) element.style.borderColor = origStyles.borderColor;
    if (origStyles.borderTopColor !== void 0) element.style.borderTopColor = origStyles.borderTopColor;
    if (origStyles.borderRightColor !== void 0) element.style.borderRightColor = origStyles.borderRightColor;
    if (origStyles.borderBottomColor !== void 0) element.style.borderBottomColor = origStyles.borderBottomColor;
    if (origStyles.borderLeftColor !== void 0) element.style.borderLeftColor = origStyles.borderLeftColor;
  });
  originalInlineStyles.clear();
}
function applyColorMap(colorMap) {
  console.log(`CS (applyColorMap): Called. Received map with ${Object.keys(colorMap).length} keys.`);
  if (Object.keys(colorMap).length < 10 && Object.keys(colorMap).length > 0) {
    console.log("CS: Full colorMap:", colorMap);
  }
  clearAppliedStyles();
  if (Object.keys(colorMap).length === 0) {
    console.log("CS: Empty color map. Styles have been cleared. No new theme applied.");
    return;
  }
  const isDarkMode = isDarkTheme(colorMap);
  const transparentMapping = colorMap["rgba(0, 0, 0, 0)"] || colorMap["transparent"] || (isDarkMode ? "#121212" : "#FFFFFF");
  console.log(`CS: Theme type: ${isDarkMode ? "Dark" : "Light"}, Transparent color mapping: ${transparentMapping}`);
  const forceBgStyle = document.createElement("style");
  forceBgStyle.textContent = `
    html, body {
      background-color: ${transparentMapping} !important;
    }
  `;
  document.head.appendChild(forceBgStyle);
  console.log("CS: Applying new color map.");
  function processElement(element) {
    if (!(element instanceof HTMLElement) || element.tagName === "SCRIPT" || element.tagName === "STYLE" || element.tagName === "NOSCRIPT") {
      return;
    }
    const htmlElement = element;
    const computedStyle = getComputedStyle(htmlElement);
    const isHtmlOrBody = element === document.documentElement || element === document.body;
    if (isDarkMode && isHtmlOrBody) {
      const currentBgColor = computedStyle.backgroundColor;
      const newColor = colorMap[currentBgColor];
      if (!newColor && currentBgColor !== "rgba(0, 0, 0, 0)" && currentBgColor !== "transparent") {
        colorMap[currentBgColor] = "#121212";
        console.log(`CS: Force-added dark mapping for ${element.tagName} background:`, currentBgColor, "→ #121212");
      }
    }
    const propertiesToProcess = [
      { computed: computedStyle.color, inlineProp: "color" },
      { computed: computedStyle.backgroundColor, inlineProp: "backgroundColor" },
      { computed: computedStyle.borderColor, inlineProp: "borderColor" },
      { computed: computedStyle.borderTopColor, inlineProp: "borderTopColor" },
      { computed: computedStyle.borderRightColor, inlineProp: "borderRightColor" },
      { computed: computedStyle.borderBottomColor, inlineProp: "borderBottomColor" },
      { computed: computedStyle.borderLeftColor, inlineProp: "borderLeftColor" }
    ];
    const originalStylesForThisElement = originalInlineStyles.get(htmlElement) || {};
    let modifiedOriginals = false;
    propertiesToProcess.forEach((item) => {
      const newColor = colorMap[item.computed];
      if (item.inlineProp === "backgroundColor" && (htmlElement === document.body || htmlElement === document.documentElement)) {
        console.log(`CS_DEBUG: BGColor Check for ${htmlElement.tagName}:`, {
          originalColor: item.computed,
          hasMapping: newColor ? true : false,
          newColor: newColor || "none"
        });
      }
      if (newColor && item.computed !== newColor) {
        if (originalStylesForThisElement[item.inlineProp] === void 0) {
          originalStylesForThisElement[item.inlineProp] = htmlElement.style[item.inlineProp] || "";
          modifiedOriginals = true;
        }
        htmlElement.style.setProperty(item.inlineProp, newColor, "important");
      }
    });
    if (modifiedOriginals) {
      originalInlineStyles.set(htmlElement, originalStylesForThisElement);
    }
  }
  if (document.documentElement) processElement(document.documentElement);
  if (document.body) {
    processElement(document.body);
    document.querySelectorAll("body *").forEach((el) => processElement(el));
  }
  currentObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          processElement(node);
          node.querySelectorAll("*").forEach((childEl) => processElement(childEl));
        }
      });
    });
  });
  if (document.documentElement) {
    currentObserver.observe(document.documentElement, { childList: true, subtree: true });
  }
  console.log("CS: Color map applied and observer set up.");
}
function collectColorsWithSemantics() {
  const allColors = /* @__PURE__ */ new Set();
  const backgroundColors = /* @__PURE__ */ new Set();
  const textColors = /* @__PURE__ */ new Set();
  const borderColors = /* @__PURE__ */ new Set();
  const accentColors = /* @__PURE__ */ new Set();
  const linkColors = /* @__PURE__ */ new Set();
  const transparentColors = /* @__PURE__ */ new Set();
  if (document.documentElement) {
    const htmlStyle = getComputedStyle(document.documentElement);
    const bgColor = htmlStyle.backgroundColor;
    allColors.add(bgColor);
    backgroundColors.add(bgColor);
    if (bgColor === "transparent" || bgColor === "rgba(0, 0, 0, 0)") {
      transparentColors.add(bgColor);
    }
    console.log("CS: HTML background color:", bgColor);
  }
  if (document.body) {
    const bodyStyle = getComputedStyle(document.body);
    const bgColor = bodyStyle.backgroundColor;
    allColors.add(bgColor);
    backgroundColors.add(bgColor);
    if (bgColor === "transparent" || bgColor === "rgba(0, 0, 0, 0)") {
      transparentColors.add(bgColor);
    }
    console.log("CS: BODY background color:", bgColor);
  }
  return {
    colors: Array.from(allColors),
    semantics: {
      backgroundColors: Array.from(backgroundColors),
      textColors: Array.from(textColors),
      borderColors: Array.from(borderColors),
      accentColors: Array.from(accentColors),
      linkColors: Array.from(linkColors),
      transparentColors: Array.from(transparentColors)
    }
  };
}
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    console.log(`CS: Received message: ${message.type}`, message);
    if (message.type === "APPLY_MAP") {
      console.log(`CS (APPLY_MAP handler): Received APPLY_MAP. Payload items: ${Object.keys(message.payload).length}. Applying...`);
      applyColorMap(message.payload);
      sendResponse({ success: true });
      return true;
    }
    if (message.type === "GET_COLORS") {
      const colorInfo = collectColorsWithSemantics();
      console.log("CS (GET_COLORS handler): Sending colors:", colorInfo.colors.length);
      sendResponse({
        colors: colorInfo.colors,
        semantics: colorInfo.semantics
      });
      return true;
    }
    console.warn("CS: Unknown message type received by content script:", message.type);
    return false;
  } catch (error) {
    console.error("CS: Error handling message:", error);
    sendResponse({ success: false, error: String(error) });
    return true;
  }
});
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    console.log(`THEMER CONTENT SCRIPT: Received message type: ${message.type}`);
    if (message.type === "APPLY_MAP") {
      console.log(`THEMER CONTENT SCRIPT: Applying color map with ${Object.keys(message.payload).length} colors`);
      applyColorMap(message.payload);
      sendResponse({ success: true });
      return true;
    }
    if (message.type === "GET_COLORS") {
    }
    sendResponse({ success: false, error: "Unknown message type" });
    return true;
  } catch (error) {
    console.error("THEMER CONTENT SCRIPT: Error processing message:", error);
    sendResponse({ success: false, error: String(error) });
    return true;
  }
});
setTimeout(() => {
  try {
    console.log("THEMER CONTENT SCRIPT: Sending test message to background");
    browser.runtime.sendMessage({
      type: "CONTENT_SCRIPT_LOADED",
      url: window.location.href,
      timestamp: Date.now()
    }).then((response) => {
      console.log("THEMER CONTENT SCRIPT: Got response from background:", response);
    }).catch((error) => {
      console.error("THEMER CONTENT SCRIPT: Error sending test message:", error);
    });
  } catch (e) {
    console.error("THEMER CONTENT SCRIPT: Error in test communication:", e);
  }
}, 1e3);
async function applyInitialTheme() {
  try {
    console.log("CS (applyInitialTheme): Function called. Requesting initial theme settings from background.");
    const activeSettings = await browser.runtime.sendMessage({ type: "GET_ACTIVE_SETTINGS_FOR_TLD" });
    console.log("CS (applyInitialTheme): Received response:", activeSettings ? `Style: ${activeSettings.style}, palette items: ${Object.keys(activeSettings.palette || {}).length}` : "null");
    if (activeSettings && activeSettings.palette && Object.keys(activeSettings.palette).length > 0) {
      console.log(`CS (applyInitialTheme): Applying initial theme. Style: ${activeSettings.style}`);
      applyColorMap(activeSettings.palette);
    } else {
      console.log("CS (applyInitialTheme): No active theme found. Applying empty map.");
      applyColorMap({});
    }
  } catch (error) {
    console.error("CS (applyInitialTheme): Error:", error);
    if (error.message.includes("Receiving end does not exist")) {
      console.warn("CS (applyInitialTheme): Background script not ready yet.");
    }
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    console.log("CS: DOMContentLoaded. Sending colors and applying initial theme.");
    if (document.body) {
      const colorInfo = collectColorsWithSemantics();
      browser.runtime.sendMessage({
        type: "COLOR_SET",
        payload: colorInfo.colors
      }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
    }
    applyInitialTheme();
  });
} else {
  console.log("CS: Document already loaded. Sending colors and applying initial theme.");
  if (document.body) {
    const colorInfo = collectColorsWithSemantics();
    browser.runtime.sendMessage({
      type: "COLOR_SET",
      payload: colorInfo.colors
    }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
  }
  applyInitialTheme();
}
try {
  const isDev = browser.runtime.getManifest().version.includes("dev") || browser.runtime.getManifest().version === "0.1.0";
  if (isDev) {
    console.log("[Themer] Running in development mode");
    window.themer = window.themer || {};
    window.themer.saveDevKey = saveDevKey;
    window.themer.checkDevKey = checkDevKey;
    window.themer.clearDevKey = clearDevKey;
    console.log('[Themer] Development utilities available. Use window.themer.saveDevKey("your-key")');
  }
} catch (e) {
  console.debug("[Themer] Could not initialize development utilities:", e);
}
