console.log("Content script loaded at", (/* @__PURE__ */ new Date()).toISOString());
try {
  let collectColors2 = function() {
    const colors = /* @__PURE__ */ new Set();
    const treeWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    let node;
    while (node = treeWalker.nextNode()) {
      const cs = getComputedStyle(node);
      ["color", "backgroundColor", "borderColor"].forEach((prop) => {
        const val = cs[prop];
        if (val && !val.startsWith("rgba(0, 0, 0, 0)")) colors.add(val);
      });
    }
    return [...colors];
  };
  var collectColors = collectColors2;
  browser.runtime.sendMessage({
    type: "COLOR_SET",
    payload: collectColors2()
  }).catch((error) => {
    console.error("Failed to send message to background script:", error);
  });
} catch (error) {
  console.error("Content script error:", error);
}
