async function saveDevKey(key) {
  if (!key || typeof key !== "string") {
    console.error("Please provide a valid API key string");
    return;
  }
  try {
    console.log("Attempting to save development API key...");
    const result = await browser.runtime.sendMessage({
      type: "SET_DEV_OPENAI_KEY",
      key
    });
    if (result.success) {
      console.log("✓ Development API key saved successfully!");
      console.log("You can now use OpenAI provider without setting a key in options.");
    } else {
      console.error("✗ Failed to save development API key:", result.error);
    }
  } catch (error) {
    console.error("✗ Error saving development API key:", error);
  }
}
async function checkDevKey() {
  try {
    const data = await browser.storage.local.get("DEV_OPENAI_KEY");
    if (data.DEV_OPENAI_KEY) {
      console.log("✓ Development API key is set");
      console.log("Key starts with:", data.DEV_OPENAI_KEY.substring(0, 5) + "...");
    } else {
      console.log("✗ No development API key is set");
      console.log('Use saveDevKey("your-key") to set one');
    }
  } catch (error) {
    console.error("Error checking development API key:", error);
  }
}
async function clearDevKey() {
  try {
    await browser.storage.local.remove("DEV_OPENAI_KEY");
    console.log("✓ Development API key cleared");
  } catch (error) {
    console.error("Error clearing development API key:", error);
  }
}
try {
  window.themer = window.themer || {};
  window.themer.saveDevKey = saveDevKey;
  window.themer.checkDevKey = checkDevKey;
  window.themer.clearDevKey = clearDevKey;
  window.saveDevKey = saveDevKey;
  window.checkDevKey = checkDevKey;
  window.clearDevKey = clearDevKey;
  console.log('[Themer] Development utilities loaded. Use saveDevKey("your-key") to store an OpenAI key.');
} catch (e) {
  console.warn("Could not expose development utilities on window:", e);
}

console.log("THEMER CONTENT SCRIPT: Initial load at", (/* @__PURE__ */ new Date()).toISOString(), window.location.href);
console.log("THEMER CONTENT SCRIPT: browser.runtime available:", !!browser.runtime);
(function checkContentScriptExecution() {
  console.log("CS: Content script initialized for", window.location.href);
  try {
    browser.runtime.sendMessage({
      type: "CONTENT_SCRIPT_LOADED",
      url: window.location.href
    }).catch((err) => console.error("CS: Error sending initial message:", err));
  } catch (e) {
    console.error("CS: Error in initialization:", e);
  }
})();
const originalInlineStyles = /* @__PURE__ */ new Map();
let currentObserver = null;
function isDarkTheme(colorMap) {
  let darkColorCount = 0;
  let totalColors = 0;
  for (const targetColor of Object.values(colorMap)) {
    if (!targetColor) continue;
    totalColors++;
    try {
      let r = 0, g = 0, b = 0;
      if (targetColor.startsWith("#")) {
        const hex = targetColor.replace("#", "");
        r = parseInt(hex.substring(0, 2), 16);
        g = parseInt(hex.substring(2, 4), 16);
        b = parseInt(hex.substring(4, 6), 16);
      } else if (targetColor.startsWith("rgb")) {
        const match = targetColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        if (match) {
          r = parseInt(match[1]);
          g = parseInt(match[2]);
          b = parseInt(match[3]);
        }
      }
      const brightness = (r * 299 + g * 587 + b * 114) / 1e3;
      if (brightness < 80) {
        darkColorCount++;
      }
    } catch (e) {
    }
  }
  return totalColors > 0 && darkColorCount / totalColors > 0.3;
}
function clearAppliedStyles() {
  console.log("CS: Clearing previously applied styles.");
  if (currentObserver) {
    currentObserver.disconnect();
    currentObserver = null;
  }
  originalInlineStyles.forEach((origStyles, element) => {
    if (!document.body || !document.body.contains(element)) {
      originalInlineStyles.delete(element);
      return;
    }
    if (origStyles.color !== void 0) element.style.color = origStyles.color;
    if (origStyles.backgroundColor !== void 0) element.style.backgroundColor = origStyles.backgroundColor;
    if (origStyles.borderColor !== void 0) element.style.borderColor = origStyles.borderColor;
    if (origStyles.borderTopColor !== void 0) element.style.borderTopColor = origStyles.borderTopColor;
    if (origStyles.borderRightColor !== void 0) element.style.borderRightColor = origStyles.borderRightColor;
    if (origStyles.borderBottomColor !== void 0) element.style.borderBottomColor = origStyles.borderBottomColor;
    if (origStyles.borderLeftColor !== void 0) element.style.borderLeftColor = origStyles.borderLeftColor;
  });
  originalInlineStyles.clear();
}
function applyColorMap(colorMap) {
  console.log(`CS (applyColorMap): Called. Received map with ${Object.keys(colorMap).length} keys.`);
  if (Object.keys(colorMap).length < 10 && Object.keys(colorMap).length > 0) {
    console.log("CS: Full colorMap:", colorMap);
  }
  clearAppliedStyles();
  if (Object.keys(colorMap).length === 0) {
    console.log("CS: Empty color map. Styles have been cleared. No new theme applied.");
    return;
  }
  const isDarkMode = isDarkTheme(colorMap);
  const styleElement = document.createElement("style");
  styleElement.id = "themer-global-styles";
  let cssRules = [];
  if (isDarkMode) {
    const darkBg = colorMap["rgb(255, 255, 255)"] || colorMap["#FFFFFF"] || colorMap["#FFF"] || colorMap["white"] || "#121212";
    const lightText = colorMap["rgb(0, 0, 0)"] || colorMap["#000000"] || colorMap["#000"] || colorMap["black"] || "#E0E0E0";
    const transparentBg = colorMap["rgba(0, 0, 0, 0)"] || colorMap["transparent"] || darkBg;
    console.log(`CS: Dark mode detected. Using base colors - Background: ${darkBg}, Text: ${lightText}, Transparent: ${transparentBg}`);
    cssRules.push(`
      /* Force dark theme basics */
      html, body {
        background-color: ${darkBg} !important;
        color: ${lightText} !important;
      }
    `);
    if (isDarkMode) {
      cssRules.push(`
        /* Dark mode fallbacks for text (catch black text not explicitly mapped) */
        p, span, div, h1, h2, h3, h4, h5, h6, a, li, td, th, label, input, textarea {
          color: ${lightText} !important;
        }
        
        /* Handle search input text */
        input[type="text"], input[type="search"], input:not([type]) {
          color: ${lightText} !important;
          background-color: #2A2A2A !important;
        }
        
        /* Force contrast for links */
        a:link, a:visited {
          color: #8CB4FF !important;
        }
      `);
      cssRules.push(`
        /* CSS Variable overrides for dark mode */
        :root {
          --text-color: ${lightText} !important;
          --body-color: ${lightText} !important;
          --body-bg: ${darkBg} !important;
          --bg-color: ${darkBg} !important;
          --background: ${darkBg} !important;
          --background-color: ${darkBg} !important;
          
          /* Material & Bootstrap variables */
          --mat-background-color: ${darkBg} !important;
          --bs-body-bg: ${darkBg} !important;
          --bs-body-color: ${lightText} !important;
        }
      `);
    }
  }
  Object.entries(colorMap).forEach(([origColor, newColor]) => {
    if (!origColor || !newColor) return;
    const cleanOrig = origColor.replace(/\s+/g, " ").trim();
    const colorId = origColor.replace(/[^a-z0-9]/gi, "-");
    cssRules.push(`
      /* Color replacements for ${cleanOrig} */
      [style*="color: ${cleanOrig}"] { color: ${newColor} !important; }
      [style*="background-color: ${cleanOrig}"] { background-color: ${newColor} !important; }
      [style*="background: ${cleanOrig}"] { background: ${newColor} !important; }
      [style*="border-color: ${cleanOrig}"] { border-color: ${newColor} !important; }
      [style*="border: ${cleanOrig}"] { border-color: ${newColor} !important; }
      
      /* Target elements that might use this color but aren't caught by attribute selectors */
      .themer-force-${colorId} { color: ${newColor} !important; background-color: ${newColor} !important; }
    `);
  });
  if (isDarkMode) {
    cssRules.push(`
      /* Common element type selectors */
      input, textarea, select, button {
        background-color: #2A2A2A !important;
        color: #E0E0E0 !important;
        border-color: #444 !important;
      }
    `);
  }
  styleElement.textContent = cssRules.join("\n");
  const observer = new MutationObserver(() => {
    if (!document.head.contains(styleElement)) {
      console.log("CS: Style element was removed, re-adding it");
      document.head.appendChild(styleElement);
    }
  });
  document.head.appendChild(styleElement);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  currentObserver = observer;
  applyInlineStyles(colorMap);
  console.log("CS: Global theme styles applied successfully");
}
function applyInlineStyles(colorMap) {
  console.log("CS: Applying inline styles for better coverage");
  const elementsToProcess = [
    document.documentElement,
    document.body,
    ...Array.from(document.querySelectorAll("div, main, article, section, header, footer, aside"))
  ];
  elementsToProcess.forEach((element) => {
    if (!(element instanceof HTMLElement)) return;
    const htmlElement = element;
    const computedStyle = getComputedStyle(htmlElement);
    const bgColor = computedStyle.backgroundColor;
    const newBgColor = colorMap[bgColor];
    if (newBgColor) {
      const origStyle = originalInlineStyles.get(htmlElement) || {};
      if (origStyle.backgroundColor === void 0) {
        origStyle.backgroundColor = htmlElement.style.backgroundColor || "";
      }
      htmlElement.style.setProperty("background-color", newBgColor, "important");
      originalInlineStyles.set(htmlElement, origStyle);
    }
    const textColor = computedStyle.color;
    const newTextColor = colorMap[textColor];
    if (newTextColor) {
      const origStyle = originalInlineStyles.get(htmlElement) || {};
      if (origStyle.color === void 0) {
        origStyle.color = htmlElement.style.color || "";
      }
      htmlElement.style.setProperty("color", newTextColor, "important");
      originalInlineStyles.set(htmlElement, origStyle);
    }
  });
}
function extractColorsFromStylesheets() {
  const extractedColors = /* @__PURE__ */ new Set();
  try {
    for (let i = 0; i < document.styleSheets.length; i++) {
      try {
        const sheet = document.styleSheets[i];
        if (sheet.href && !sheet.href.startsWith(window.location.origin) && !sheet.href.startsWith("moz-extension://")) {
          continue;
        }
        const rules = sheet.cssRules || sheet.rules;
        if (!rules) continue;
        for (let j = 0; j < rules.length; j++) {
          const rule = rules[j];
          if (rule instanceof CSSStyleRule) {
            const style = rule.style;
            ["color", "background-color", "border-color", "background"].forEach((prop) => {
              const value = style.getPropertyValue(prop);
              if (value && !value.includes("var(") && value !== "transparent" && value !== "inherit" && value !== "initial") {
                extractedColors.add(value);
              }
            });
          }
        }
      } catch (e) {
      }
    }
  } catch (e) {
    console.error("CS: Error extracting colors from stylesheets:", e);
  }
  return extractedColors;
}
function collectColorsWithSemantics() {
  const allColors = /* @__PURE__ */ new Set();
  const backgroundColors = /* @__PURE__ */ new Set();
  const textColors = /* @__PURE__ */ new Set();
  const borderColors = /* @__PURE__ */ new Set();
  const accentColors = /* @__PURE__ */ new Set();
  const linkColors = /* @__PURE__ */ new Set();
  const transparentColors = /* @__PURE__ */ new Set();
  if (document.documentElement) {
    const htmlStyle = getComputedStyle(document.documentElement);
    const bgColor = htmlStyle.backgroundColor;
    allColors.add(bgColor);
    backgroundColors.add(bgColor);
    if (bgColor === "transparent" || bgColor === "rgba(0, 0, 0, 0)") {
      transparentColors.add(bgColor);
    }
    console.log("CS: HTML background color:", bgColor);
  }
  if (document.body) {
    const bodyStyle = getComputedStyle(document.body);
    const bgColor = bodyStyle.backgroundColor;
    allColors.add(bgColor);
    backgroundColors.add(bgColor);
    if (bgColor === "transparent" || bgColor === "rgba(0, 0, 0, 0)") {
      transparentColors.add(bgColor);
    }
    console.log("CS: BODY background color:", bgColor);
  }
  console.log("CS: Extracting colors from stylesheets");
  const stylesheetColors = extractColorsFromStylesheets();
  console.log(`CS: Found ${stylesheetColors.size} colors in stylesheets`);
  stylesheetColors.forEach((color) => {
    allColors.add(color);
  });
  return {
    colors: Array.from(allColors),
    semantics: {
      backgroundColors: Array.from(backgroundColors),
      textColors: Array.from(textColors),
      borderColors: Array.from(borderColors),
      accentColors: Array.from(accentColors),
      linkColors: Array.from(linkColors),
      transparentColors: Array.from(transparentColors)
    }
  };
}
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    console.log(`THEMER: Received message: ${message.type}`, message);
    if (message.type === "APPLY_MAP") {
      console.log(`THEMER: Applying color map with ${Object.keys(message.payload).length} colors`);
      applyColorMap(message.payload);
      sendResponse({ success: true });
      return true;
    }
    if (message.type === "GET_COLORS") {
      const colorInfo = collectColorsWithSemantics();
      console.log("THEMER: Sending colors:", colorInfo.colors.length);
      sendResponse({
        colors: colorInfo.colors,
        semantics: colorInfo.semantics
      });
      return true;
    }
    console.warn("THEMER: Unknown message type:", message.type);
    sendResponse({ success: false, error: "Unknown message type" });
    return true;
  } catch (error) {
    console.error("THEMER: Error handling message:", error);
    sendResponse({ success: false, error: String(error) });
    return true;
  }
});
setTimeout(() => {
  try {
    console.log("THEMER CONTENT SCRIPT: Sending test message to background");
    browser.runtime.sendMessage({
      type: "CONTENT_SCRIPT_LOADED",
      url: window.location.href,
      timestamp: Date.now()
    }).then((response) => {
      console.log("THEMER CONTENT SCRIPT: Got response from background:", response);
    }).catch((error) => {
      console.error("THEMER CONTENT SCRIPT: Error sending test message:", error);
    });
  } catch (e) {
    console.error("THEMER CONTENT SCRIPT: Error in test communication:", e);
  }
}, 1e3);
async function applyInitialTheme() {
  try {
    console.log("CS (applyInitialTheme): Function called. Requesting initial theme settings from background.");
    const activeSettings = await browser.runtime.sendMessage({ type: "GET_ACTIVE_SETTINGS_FOR_TLD" });
    console.log("CS (applyInitialTheme): Received response:", activeSettings ? `Style: ${activeSettings.style}, palette items: ${Object.keys(activeSettings.palette || {}).length}` : "null");
    if (activeSettings && activeSettings.palette && Object.keys(activeSettings.palette).length > 0) {
      console.log(`CS (applyInitialTheme): Applying initial theme. Style: ${activeSettings.style}`);
      applyColorMap(activeSettings.palette);
    } else {
      console.log("CS (applyInitialTheme): No active theme found. Applying empty map.");
      applyColorMap({});
    }
  } catch (error) {
    console.error("CS (applyInitialTheme): Error:", error);
    if (error.message.includes("Receiving end does not exist")) {
      console.warn("CS (applyInitialTheme): Background script not ready yet.");
    }
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    console.log("CS: DOMContentLoaded. Sending colors and applying initial theme.");
    if (document.body) {
      const colorInfo = collectColorsWithSemantics();
      browser.runtime.sendMessage({
        type: "COLOR_SET",
        payload: colorInfo.colors
      }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
    }
    applyInitialTheme();
  });
} else {
  console.log("CS: Document already loaded. Sending colors and applying initial theme.");
  if (document.body) {
    const colorInfo = collectColorsWithSemantics();
    browser.runtime.sendMessage({
      type: "COLOR_SET",
      payload: colorInfo.colors
    }).catch((e) => console.error("CS: Error sending COLOR_SET:", e));
  }
  applyInitialTheme();
}
try {
  const isDev = browser.runtime.getManifest().version.includes("dev") || browser.runtime.getManifest().version === "0.1.0";
  if (isDev) {
    console.log("[Themer] Running in development mode");
    window.themer = window.themer || {};
    window.themer.saveDevKey = saveDevKey;
    window.themer.checkDevKey = checkDevKey;
    window.themer.clearDevKey = clearDevKey;
    console.log('[Themer] Development utilities available. Use window.themer.saveDevKey("your-key")');
  }
} catch (e) {
  console.debug("[Themer] Could not initialize development utilities:", e);
}
(function verifyContentScriptRunning() {
  const indicator = document.createElement("div");
  indicator.id = "themer-content-script-indicator";
  indicator.style.cssText = "position:fixed;top:0;right:0;background:red;color:white;padding:2px 5px;z-index:999999;font-size:10px;";
  indicator.textContent = "Themer Active";
  document.documentElement.appendChild(indicator);
  setTimeout(() => {
    if (indicator && indicator.parentNode) {
      indicator.parentNode.removeChild(indicator);
    }
  }, 5e3);
})();
