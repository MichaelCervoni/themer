import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from './assets/client-Cgcb47Pj.js';

const INITIAL = { provider: "ollama" };
function Options() {
  const [state, setState] = reactExports.useState(INITIAL);
  const [saved, setSaved] = reactExports.useState(false);
  reactExports.useEffect(() => {
    browser.storage.local.get(["provider", "openaiKey", "claudeKey", "ollamaUrl"]).then((res) => setState({ ...INITIAL, ...res }));
  }, []);
  const save = async () => {
    await browser.storage.local.set(state);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "form",
    {
      className: "space-y-4",
      onSubmit: (e) => {
        e.preventDefault();
        save();
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { className: "font-medium mb-1", children: "LLM Provider" }),
          [
            { id: "ollama", label: "Local Ollama" },
            { id: "openai", label: "OpenAI" },
            { id: "claude", label: "Anthropic Claude" }
          ].map(({ id, label }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "radio",
                name: "provider",
                value: id,
                checked: state.provider === id,
                onChange: () => setState((s) => ({ ...s, provider: id }))
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2", children: label })
          ] }, id))
        ] }),
        state.provider === "ollama" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-medium mb-1", children: "Ollama Base URL" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "url",
              className: "w-full border rounded p-1",
              value: state.ollamaUrl ?? "http://localhost:11434",
              onChange: (e) => setState((s) => ({ ...s, ollamaUrl: e.target.value }))
            }
          )
        ] }),
        state.provider === "openai" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-medium mb-1", children: "OpenAI API Key" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "password",
              className: "w-full border rounded p-1",
              value: state.openaiKey ?? "",
              onChange: (e) => setState((s) => ({ ...s, openaiKey: e.target.value }))
            }
          )
        ] }),
        state.provider === "claude" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-medium mb-1", children: "Claude API Key" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "password",
              className: "w-full border rounded p-1",
              value: state.claudeKey ?? "",
              onChange: (e) => setState((s) => ({ ...s, claudeKey: e.target.value }))
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "submit",
            className: "rounded bg-indigo-600 text-white py-1 px-4 hover:bg-indigo-700",
            children: "Save"
          }
        ),
        saved && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-700 ml-3", children: "✔ Saved!" })
      ]
    }
  );
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(Options, {}));
