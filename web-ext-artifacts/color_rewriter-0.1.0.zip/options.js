import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from './assets/client-DWMWtjFw.js';

async function checkOllamaAvailability(baseUrl = "http://127.0.0.1:11434") {
  try {
    console.log(`Checking Ollama availability at: ${baseUrl}`);
    const cleanBaseUrl = baseUrl.replace(/\/$/, "");
    const testUrl = `${cleanBaseUrl}/api/tags`;
    console.log("Using background script proxy to avoid CORS issues");
    if (!browser || !browser.runtime) {
      console.error("Proxy request failed: browser.runtime is not available");
      return {
        available: false,
        error: "Browser runtime or extension messaging API not available",
        debug: { browserExists: !!browser, runtimeExists: !!(browser && browser.runtime) }
      };
    }
    if (!browser.runtime.sendMessage) {
      console.error("Proxy request failed: browser.runtime.sendMessage is not available");
      return {
        available: false,
        error: "Browser runtime messaging API not available",
        debug: { browserExists: !!browser, runtimeExists: !!(browser && browser.runtime), sendMessageExists: !!(browser && browser.runtime && browser.runtime.sendMessage) }
      };
    }
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject({
        available: false,
        error: "Timeout waiting for response from background script (10 seconds)"
      }), 1e4);
    });
    const messagePromise = browser.runtime.sendMessage({
      type: "OLLAMA_PROXY",
      url: testUrl,
      method: "GET",
      headers: { "Accept": "application/json" }
    }).then((proxyResponse) => {
      console.log("Received response from proxy:", proxyResponse);
      if (!proxyResponse) {
        console.error("Proxy request failed: Empty response");
        return {
          available: false,
          error: "Empty response from proxy",
          debug: { proxyResponse }
        };
      }
      if (!proxyResponse.success && !proxyResponse.ok) {
        console.error("Proxy request failed:", proxyResponse.error || "Unknown error");
        return {
          available: false,
          error: proxyResponse.error || `Failed to connect (${proxyResponse.status || "Unknown error"})`,
          debug: { proxyResponse }
        };
      }
      let data;
      try {
        if (proxyResponse.data) {
          data = proxyResponse.data;
        } else if (proxyResponse.text) {
          data = JSON.parse(proxyResponse.text);
        } else {
          throw new Error("No data or text in response");
        }
      } catch (e) {
        console.error("Failed to parse proxy response:", e);
        return {
          available: false,
          error: `Failed to parse response: ${e instanceof Error ? e.message : String(e)}`,
          debug: { proxyResponse, responseType: typeof proxyResponse, responseKeys: Object.keys(proxyResponse) }
        };
      }
      console.log("Parsed data from proxy:", data);
      if (!data.models || !Array.isArray(data.models) || data.models.length === 0) {
        return {
          available: true,
          models: [],
          error: "No models found on the server",
          debug: { data }
        };
      }
      return {
        available: true,
        models: data.models.map((m) => m.name),
        debug: { data }
      };
    }).catch((error) => {
      console.error("Error in proxy request:", error);
      return {
        available: false,
        error: error instanceof Error ? error.message : String(error),
        debug: { error }
      };
    });
    return Promise.race([messagePromise, timeoutPromise]);
  } catch (error) {
    console.error("Error checking Ollama availability:", error);
    return {
      available: false,
      error: error instanceof Error ? error.message : String(error),
      debug: { errorObject: error }
    };
  }
}

async function saveDevOpenAIKey(key) {
  try {
    if (!key || typeof key !== "string" || key.length < 10) {
      return {
        success: false,
        error: "Please provide a valid API key"
      };
    }
    await browser.storage.local.set({
      DEV_OPENAI_KEY: key
    });
    return {
      success: true
    };
  } catch (error) {
    console.error("Error saving development API key:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error saving key"
    };
  }
}

const INITIAL = { provider: "openai" };
function Options() {
  const [state, setState] = reactExports.useState(INITIAL);
  const [saved, setSaved] = reactExports.useState(false);
  const [devKey, setDevKey] = reactExports.useState("");
  reactExports.useEffect(() => {
    browser.storage.local.get(["provider", "openaiKey", "claudeKey", "ollamaUrl"]).then((res) => setState({ ...INITIAL, ...res }));
  }, []);
  const save = async () => {
    await browser.storage.local.set(state);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };
  const debugOllamaConnection = async (url) => {
    const results = [];
    let directFetchSuccess = false;
    let proxySuccess = false;
    try {
      results.push("1. Testing direct fetch (expected to fail due to CORS)");
      const directResponse = await fetch(`${url.replace(/\/$/, "")}/api/tags`, {
        method: "GET",
        headers: { "Accept": "application/json" }
      });
      results.push(`✓ Direct fetch succeeded (unexpected): ${directResponse.status} ${directResponse.statusText}`);
      directFetchSuccess = true;
    } catch (error) {
      results.push(`✗ Direct fetch failed as expected: ${error instanceof Error ? error.message : String(error)}`);
    }
    try {
      results.push("\n2. Testing background script proxy (should succeed)");
      const proxyResponse = await browser.runtime.sendMessage({
        type: "OLLAMA_PROXY",
        url: `${url.replace(/\/$/, "")}/api/tags`,
        method: "GET"
      });
      if (proxyResponse.ok || proxyResponse.success) {
        results.push(`✓ Proxy fetch succeeded: ${proxyResponse.status || "200"}`);
        proxySuccess = true;
        try {
          const data = proxyResponse.data || JSON.parse(proxyResponse.text);
          const modelCount = data.models?.length || 0;
          results.push(`✓ Found ${modelCount} models: ${data.models?.map((m) => m.name).join(", ") || "none"}`);
        } catch (e) {
          results.push(`✗ Could not parse models from response: ${e instanceof Error ? e.message : String(e)}`);
        }
      } else {
        results.push(`✗ Proxy fetch failed: ${proxyResponse.error || "Unknown error"}`);
        results.push(`Full error details: ${JSON.stringify(proxyResponse)}`);
      }
    } catch (error) {
      results.push(`✗ Proxy message error: ${error instanceof Error ? error.message : String(error)}`);
    }
    results.push("\n3. System-level check (should succeed):");
    try {
      const sysResponse = await browser.runtime.sendMessage({
        type: "OLLAMA_SYSTEM_CHECK",
        url: `${url.replace(/\/$/, "")}/api/tags`
      });
      if (sysResponse.success) {
        results.push(`✓ System check succeeded: status ${sysResponse.status || "200"}`);
        if (sysResponse.models && sysResponse.models.length) {
          results.push(`✓ Models found: ${sysResponse.models.join(", ")}`);
        } else {
          results.push("✗ No models found on server");
        }
      } else {
        results.push(`✗ System check failed: ${sysResponse.error || "Unknown error"}`);
      }
    } catch (error) {
      results.push(`✗ System check error: ${error instanceof Error ? error.message : String(error)}`);
    }
    results.push("\nSummary:");
    results.push(`Direct fetch: ${directFetchSuccess ? "✓ Success (unexpected)" : "✗ Failed (expected due to CORS)"}`);
    results.push(`Proxy via background: ${proxySuccess ? "✓ Success" : "✗ Failed (this is the issue)"}`);
    results.push("\nTechnical Info:");
    results.push(`Browser/Runtime available: ${!!browser && !!browser.runtime ? "Yes" : "No"}`);
    results.push(`URL being tested: ${url}`);
    results.push(`Extension ID: ${browser.runtime.id || "unknown"}`);
    return results.join("\n");
  };
  const testConnection = async () => {
    try {
      const baseUrlToTest = state.ollamaUrl || "http://127.0.0.1:11434";
      console.log("Testing connection to:", baseUrlToTest);
      await browser.storage.local.set({
        provider: state.provider,
        ollamaUrl: state.ollamaUrl,
        openaiKey: state.openaiKey,
        claudeKey: state.claudeKey
      });
      console.log("Settings saved before connection test");
      if (baseUrlToTest === "debug") {
        alert("Debug mode enabled. Mock data will be used instead of real API calls.");
        return;
      }
      const debugResults = await debugOllamaConnection(baseUrlToTest);
      console.log("Debug results:", debugResults);
      alert(`Testing connection to ${baseUrlToTest}...

${debugResults}`);
      const result = await checkOllamaAvailability(baseUrlToTest);
      if (result.available) {
        if (result.models && result.models.length > 0) {
          alert(`Connection successful! Available models: ${result.models.join(", ")}`);
        } else {
          alert("Connection successful but no models were found. Please install models with 'ollama pull llama3' or similar.");
        }
      } else {
        throw new Error(result.error || "Unknown connection error");
      }
    } catch (error) {
      console.error("Connection test failed:", error);
      alert(`Error: ${error instanceof Error ? error.message : String(error)}

Please check:
1. Is Ollama running?
2. Is the URL correct? (try http://127.0.0.1:11434)
3. Or use "debug" as URL to use mock data instead`);
    }
  };
  const handleSaveDevKey = async () => {
    try {
      if (!devKey || devKey.length < 10) {
        alert("Please enter a valid OpenAI API key");
        return;
      }
      const result = await saveDevOpenAIKey(devKey);
      if (result.success) {
        alert("Development API key saved successfully!");
        setDevKey("");
      } else {
        alert(`Error: ${result.error || "Unknown error"}`);
      }
    } catch (error) {
      alert(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
  };
  const runNetworkDiagnostics = async () => {
    try {
      const baseUrl = state.ollamaUrl || "http://127.0.0.1:11434";
      alert("Running network diagnostics. This may take a moment...");
      const results = await browser.runtime.sendMessage({
        type: "OLLAMA_SYSTEM_CHECK",
        url: baseUrl + "/api/tags"
      });
      if (results.success) {
        alert("Connection successful!\n\nOllama appears to be running and accessible from the extension. If you're still having issues, check that you have models installed with 'ollama pull llama3'.");
      } else {
        alert("Connection failed: " + (results.error || "Unknown error") + "\n\nRecommendations:\n1. Make sure Ollama is running (run 'ollama serve' in terminal)\n2. Try using http://localhost:11434 or http://127.0.0.1:11434\n3. Use 'debug' as URL to use mock data instead of real API calls");
      }
    } catch (error) {
      alert("Error running diagnostics: " + (error instanceof Error ? error.message : String(error)));
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "form",
    {
      className: "space-y-4",
      onSubmit: (e) => {
        e.preventDefault();
        save();
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { className: "font-medium mb-1", children: "LLM Provider" }),
          [
            { id: "ollama", label: "Local Ollama" },
            { id: "openai", label: "OpenAI" },
            { id: "claude", label: "Anthropic Claude" }
          ].map(({ id, label }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "radio",
                name: "provider",
                value: id,
                checked: state.provider === id,
                onChange: () => setState((s) => ({ ...s, provider: id }))
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2", children: label })
          ] }, id))
        ] }),
        state.provider === "ollama" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-medium mb-1", children: "Ollama Base URL" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "url",
              className: "w-full border rounded p-1",
              value: state.ollamaUrl ?? "http://localhost:11434",
              onChange: (e) => setState((s) => ({ ...s, ollamaUrl: e.target.value }))
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs mt-1 text-gray-600", children: 'Enter "debug" to use mock responses for testing. Example: http://127.0.0.1:11434' }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: testConnection,
                className: "mt-2 rounded bg-blue-500 text-white py-1 px-4 hover:bg-blue-600",
                children: "Test Ollama Connection"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: runNetworkDiagnostics,
                className: "mt-2 rounded bg-gray-500 text-white py-1 px-4 hover:bg-gray-600",
                children: "Network Diagnostics"
              }
            )
          ] })
        ] }),
        state.provider === "openai" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-medium mb-1", children: "OpenAI API Key" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "password",
              className: "w-full border rounded p-1",
              value: state.openaiKey ?? "",
              onChange: (e) => setState((s) => ({ ...s, openaiKey: e.target.value }))
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 border-t pt-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-medium mb-1 text-sm text-gray-700", children: "Development API Key" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex space-x-2 mt-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "password",
                  placeholder: "Enter OpenAI API key for development",
                  className: "flex-grow border rounded p-1 text-sm",
                  value: devKey,
                  onChange: (e) => setDevKey(e.target.value)
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: handleSaveDevKey,
                  className: "bg-gray-200 hover:bg-gray-300 text-gray-800 text-xs py-1 px-2 rounded",
                  children: "Save Dev Key"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs mt-1 text-gray-500", children: "This key is stored separately and used as a fallback during development" })
          ] })
        ] }),
        state.provider === "claude" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-medium mb-1", children: "Claude API Key" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "password",
              className: "w-full border rounded p-1",
              value: state.claudeKey ?? "",
              onChange: (e) => setState((s) => ({ ...s, claudeKey: e.target.value }))
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "submit",
            className: "rounded bg-indigo-600 text-white py-1 px-4 hover:bg-indigo-700",
            children: "Save"
          }
        ),
        saved && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-700 ml-3", children: "✔ Saved!" })
      ]
    }
  );
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(Options, {}));
